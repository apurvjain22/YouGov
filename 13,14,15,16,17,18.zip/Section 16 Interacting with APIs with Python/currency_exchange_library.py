import time
from libs.openexhangeclient_ttl_usage import OpenExchangeClient
from libs.openexchangeclient import OpenExchangeClient

APP_ID = "2c80cd24ca9b4e4e9d10147f3c208da9"

client = OpenExchangeClient(APP_ID)

usd_amount = 1000
start = time.time()
gbp_amount = client.convert(usd_amount, "USD", "GBP")
end = time.time()

print(end - start) # it will display how much time a convert fn takes.
print(f"USD {usd_amount} is GBP {gbp_amount:.2f}")



