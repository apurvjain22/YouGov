import requests

APP_ID = "2c80cd24ca9b4e4e9d10147f3c208da9"
ENDPOINT = "https://openexchangerates.org/api/latest.json"

response = requests.get(f"{ENDPOINT}?app_id={APP_ID}") # this builds the address.
exchange_rates = response.json()["rates"] # accessing the rate key in the json file.

usd_amount = 1000
gbp_amount = usd_amount * exchange_rates["GBP"]

print(f"USD {usd_amount} is GBP {gbp_amount}")



