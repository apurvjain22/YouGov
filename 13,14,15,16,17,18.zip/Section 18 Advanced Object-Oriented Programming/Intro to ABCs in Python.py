'''
    - ABCs is Abstract Base Class
    - ABCs are pretty useful in Python because they let you define some functionality without implementing it.
'''
from abc import ABCMeta, abstractmethod
'''
    - Now, ABCMeta is a real class but it allows us to some things that normal classes don't allow us to do
      and that's using this abstractmethod.
'''

class Animal(metaclass=ABCMeta):
    '''
    We cannot instantiate Animal class as we have inherited this class by ABCmeta class.
    Animal class would become to extract functionality and gives us a bit of info. and we cannot interact it with directly.
    '''

    def walk(self):
        print('Walking')

    @abstractmethod
    def num_legs(self):
        pass
'''
    - By defining the abstractmethod, we've said Animal has num_legs method, 
    - but it's not about a specific animal in the world, its a bit abstract, it doesn't refer to anything concrete,
    - so then it is the responsibility of the child classes, like Dog and Monkey to implement that method.
    - And it becomes the necessity of the all the classes which inherits the Animal class, to have num_legs fn, 
    - else it would throw an error. 
'''

class Dog(Animal):
    def __init__(self, name):
        self.name = name

    def num_legs(self):
        return 4


class Monkey(Animal):
    def __init__(self, name):
        self.name = name

    def num_legs(self):
        return 2

# as wkt, Dog and Monkey are subclasses of Animal, so we can do like below
animals = [Dog('Rolf'), Monkey('Bob')]
for a in animals:
    print(isinstance(a, Animal))
    # This is the same for all inheritance in Python, we know, A is an instance of animal,
    # but it has also been extended by the subclass. So Python says yes, this is an animal
    # in that it has all the methods and the properties of the animal.
    print(a.num_legs())