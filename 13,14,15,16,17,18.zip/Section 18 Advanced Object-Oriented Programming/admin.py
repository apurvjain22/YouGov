from user import User
# from Database import Database # no longer need this
from saveable import Saveable


# Admin inherits from the user. All the method of User can be accessed through Admin class as well.
class Admin(User, Saveable):
    '''
    User is the first class which inherited and Saveable is the second.
    So by using multiple inheritance like this, we can actually extract functionality
    that is shared amongst similar objects, and similar classes, like user to admin,
    '''

    def __init__(self, username, password, access):
        super(Admin, self).__init__(username, password) # calling the init method of inherited User class,
        # to initialize the arguments given to the Admin class while calling the class.
        self.access = access

    def __repr__(self):
        return f"<Admin {self.username}, access {self.access}>"

    def to_dict(self):
        '''
        represents the Admin
        '''
        return {
            'username': self.username,
            'password': self.password,
            'access': self.access
        }


    '''def save(self):
        Database.insert(self.to_dict())
        This method is also not required '''


    # self.save() will be searched in Admin
    # then in User
    # then in Saveable, where it will be found

    # self.save() uses self.to_dict

    # self.to_dict() will be searched for in Admin, where it will be found.