class Promotable:
    # define Promotable class and associated methods here
    def promote(self, hourly):
        self.rate = self.rate + hourly