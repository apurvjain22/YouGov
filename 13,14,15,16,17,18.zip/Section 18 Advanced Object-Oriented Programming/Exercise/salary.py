class Salary:
    # define Salary class and associated methods here
    def calculate(self, weekly):
        return self.rate * weekly
