from Database import Database


class Store:
    def to_dict(self):
        pass

    def save(self):
        Database.insert(self.to_dict)
    '''
    - We can see that there are 2 method names are common in between store and admin
        - to_dict() is partially same
        - save() is fully same
    '''