from abc import ABCMeta, abstractmethod
from Database import  Database


class Saveable(metaclass=ABCMeta):
    def save(self):
        Database.insert(self.to_dict())

    '''
    We can see that savable class doesn't have to_dict(), it is relying admin method
    So we will force the to_dict() to implement forcefully here by using ABC class.
    '''
    @abstractmethod
    def to_dict(self):
        pass
    '''
    So Saveable gets to_dict(), but this method is actually doing in admin class only.
    '''

'''
    - As we are using the ABC class here, so Saveable class becomes the super class of all.
    - So we cannot instantiate Saveable class, and also cannot be called directly.
    - It would be called as Interface because it is defining the functionality should be in a subclass.
    - An Interface is not a class that we can instantiate instead, 
    - it is a thing in programming that defines what a subclass can do.
    - So subclasses has implemented the to.dict method and we can also add some functionality that
    - is shared amongst the subclasses, like this save method.
    
    - So pretty useful in Python that these interfaces can have both definitions of what the subclass must
    - be able to do, must implement, and also provide some functionality that will be shared among subclasses.
'''

