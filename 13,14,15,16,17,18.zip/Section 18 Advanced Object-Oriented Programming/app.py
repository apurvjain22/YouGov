from admin import Admin
from Database import Database
from user import User
from saveable import Saveable

# This is perfectly fine because each user is a subclass or implements the saveable interface.
#u = User('rolf', '1234')
a = Admin('rolf', '1234', 3)

print(a.save())

# print(Database.find(lambda x: x['username'] == 'rolf'))