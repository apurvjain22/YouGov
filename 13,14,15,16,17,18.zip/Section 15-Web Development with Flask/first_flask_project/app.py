from flask import Flask, render_template, request, redirect, url_for

# We are using dunder name method here, it is just because that's always going to be unique
# for an application, we know that the file we run has a name of main and all the other files
# are gonna have different names so there's no chance of us creating another Flask app with the same name
# throughout our entire application by mistake.
app = Flask(__name__)

# storing the post contents
posts = {
    0:{
        'post_id': 0,
        'title': 'Hello World!',
        'content': 'This is my first blog post!'
    }
}

@app.route('/') # we use app.route() decorator to tell Flask what URL should trigger our fn.
# '/' is always pointing to the homepage. As soon as we visit the URL http://127.0.0.1:5000/, it will trigger home fn.
def home(): # by default in the homepage we will be getting Hello World!
    return 'Hello, World!'

'''
When we have only create a 'create' fn, the problem which we faced is:

    - What was happening is, the form is sending the data to a page.That page can then choose to use that data or not.
    - So when we press submit, the browser sends another GET request to the URL- /post/form
    - and it includes query string parameter behind the URL- /post/form 
    - Query string parameter- ?title= something and content equals something else.
    - when we access the endpoint in a create fn, only rendered/use a template,
    - it doesn't use the data that it received in the query string parameters.  
    - It is unable to do anything with them, and all that happens is we re-run the template.
'''
# this is one endpoint to retrieve the data
@app.route('/post/form') # URL for seeing the contents of the post
def form():
    return render_template('create.jinja2')


# So we will create another endpoint so that we could store the data we receive
@app.route('/post/create') # 127.0.0.1:5000/post/create?title=something&content=something_else
def create():
    title = request.args.get('title') # This request is like a global variable and also some request
    # is coming to this endpoint. And also it has some attributes/args which we are accessing it.
    content = request.args.get('content')
    post_id = len(posts) # Just so when you access a particular post, we'll also have access to its ID.
    posts[post_id] = {'post_id': post_id, 'title': title, 'content': content}
    return redirect(url_for('post', post_id=post_id))
    # The URL for, takes in a function name and returns a URL, an address that we want.
    # In this case, it takes the post fn name, which is defined up and it's gonna give us the URL- '/post/form'
    # So the post URL needs a post_id in order to be complete, and we can do that inside the url_for fn.
    # The redirect is wrapping this url_for and what it does is it sends a response back to the browser
    # telling the browser that it should actually not load "create" page,
    # rather, it should go and load "/post/1" page instead.


@app.route('/post/<int:post_id>') # post/0- this '0' id will act as a key and fetch from data from the posts dict
def post(post_id):
    post = posts.get(post_id) # retrieving the contents if the post
    if not post: # post will be None if not found; not None => True
        return render_template('404.jinja2', message = f'A post with id {post_id} was not found')
    return render_template('post.jinja2',post = posts.get(post_id)) # here the post variable has been given in the post.jinja2


# we have to run our app to start the server that allows Flask to receive connections.
#  if name is main, so that we only run this when we actually want to run it
if __name__ == '__main__':
    app.run(debug=True) # debug for development purposes, if any error occurs we can check the logs
    # Once the app is completed, we can remove the debug option.



