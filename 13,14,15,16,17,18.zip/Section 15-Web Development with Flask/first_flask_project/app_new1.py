from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

posts = {
    0:{
        'post_id': 0,
        'title': 'Hello World!',
        'content': 'This is my first blog post!'
    }
}

@app.route('/')
def home():
    return 'Hello, World!'


@app.route('/post/form')
def form():
    return render_template('create.jinja2')


'''
@app.route('/post/create') # 127.0.0.1:5000/post/create?title=something&content=something_else
def create():
    title = request.args.get('title') 
    content = request.args.get('content')
    post_id = len(posts) # Just so when you access a particular post, we'll also have access to its ID.
    posts[post_id] = {'id': post_id, 'title': title, 'content': content}
    return redirect(url_for('post', post_id=post_id))
    
    - In the above code when we access the URL, the contents are easily accessible by others.
    - So to hide the contents, by using the hidden payload that comes through in the request i.e. POST method

'''
# Instead of accessing the query string parameters, we're gonna be accessing the request.form data.
# This is some hidden data that is included when we send the form using HTML,
# but of course the address is still gonna be the same.

'''
@app.route('/post/create')
This endpoint here though is only geared up to accept GET requests.If we want to accept a POST request
that has that hidden payload of data, we must tell Flask that we want to link this root app
with a way to access POST requests.
'''
@app.route('/post/create', methods=['POST']) # Now we've told Flask that this root here will only receive POST requests.
# And if we try to access through GET, it will throw an error.
# URL - 127.0.0.1:5000/post/create?title=something&content=something_else
def create():
    title = request.form.get('title') # So we don't want the address to be the above one.
    # We want the form to not send the data in the above format. Instead, we want the form to send data as a hidden payload
    content = request.form.get('content')
    post_id = len(posts) # Just so when you access a particular post, we'll also have access to its ID.
    posts[post_id] = {'id': post_id, 'title': title, 'content': content}
    return redirect(url_for('post', post_id=post_id))


@app.route('/post/<int:post_id>') # post/0- this '0' id will act as a key and fetch from data from the posts dict
def post(post_id):
    post = posts.get(post_id)
    if not post: # post will be None if not found; not None => True
        return render_template('404.jinja2', message = f'A post with id {post_id} was not found')
    return render_template('post.jinja2',post = posts.get(post_id))


if __name__ == '__main__':
    app.run(debug=True)


