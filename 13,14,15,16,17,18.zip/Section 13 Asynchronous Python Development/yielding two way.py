# yielding from another iterator
from collections import deque

friends = deque(('Rolf', 'Jose', 'Charlie', 'Jen', 'Anna'))

def get_friend(): # generator
    yield from friends


def greet(g): # g is a generator which is passed here
    while True: # it will not run continuously because yield will suspend the fn until next is being called.
        try:
            friend = next(g) # getting the next value of the generator
            yield f"Hello {friend}" # yielding/returning the value
        except StopIteration:
            pass

friends_generator = get_friend()
g = greet(friends_generator)
print(next(g)) # calling the chain of generators.
print(next(g))

# when e are calling next(g), it is running greet fn and then it is running get_friend fn and
# both of these fn will get suspend until next fn is called again. And then again the chain of generators will be called