import time
from threading import Thread # this gives access to threads

def ask_user():
    start = time.time()
    user_input = input("Enter you name: ") # this is a blocking operation, for which thread will wait.
    greet = f"hello {user_input}" # thread will not wait for this statement
    print(greet) # thread will not wait for this operation.
    print(f"ask_user, {time.time() - start}")

def complex_calculation():
    start = time.time()
    print("Started calculating...")
    var = [x ** 2 for x in range(20000000)]
    print(f"complex_calculation, {time.time() - start}")

start = time.time()
ask_user()
complex_calculation()
print(f"Single thread total time: {time.time() - start}") # some extra time is added,
# this is because the cursor to jump from one fn to another.

# we will not run the fn here, we will just the reference of the fn.
thread1 = Thread(target=complex_calculation)
thread2 = Thread(target=ask_user)

# So now 3 threads are running: thread1, thread2 and the main thread i.e.
# A thread which is responsible for running the other 2 threads.
start = time.time()

thread1.start()
thread2.start()

'''
Here we can write a code to kill a thread, like after matching the certain criteria but we shouldn't be doing it.
    Drawbacks of killing the threads:
        - If we kill the thread1, then it might be possible that thread1 would be using GIL, 
          and before the GIL is released from thread1, GIL will be killed and thread2 will not be able to run. 
        - Threads will not release the resources just by killing them. 
        - If you have your thread and it's started, and it's using the GIL and then you kill it,
          the GIL is gone, no other thread can get the GIL, your Python programme will stop.
        - It won't terminate, because the thread here will be waiting to finish, but it won't be able to do anything,
          and if that happens, if you have a resource that's being used and nothing else can use it,
          this is called a deadlock in computing,
        
# So we shouldn't kill thread, instead we should always wait for the thread to finish. 
'''

thread1.join()
thread2.join()

print(f"Two thread total time is: {time.time() - start}")