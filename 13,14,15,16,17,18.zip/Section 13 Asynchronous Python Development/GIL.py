'''
# Process
    - contains atleast one thread and some resources. So the process can deal with going into a core,
      coming out of the core, reserving some resources it needs, like access to a file or something like that.
'''

'''
- When we launch a python app(eg: via PyCharm), we get a new python process and along with it a new thread
  which runs the code from top to bottom. 
- But we can make more threads if we want, provided that one thread runs on one core.
- The benefit of making more threads is we can run one thread in each core.
- Similarly, python can make 2 threads and run them in two cores at the same time.

# Can we run multiple threads in python?
 
- In python we cannot implement 2 threads in a process at the same time.
- So if our python process creates 2 threads i.e. 1 main thread and 2. another thread, are not going to run at the same
  time, even if we have 2 cores.
- And this is because every process in python creates a key resource i.e. a critical resource and 
  when the thread is running, it must acquire that resource. And python will check, if the process has acquired 
  that key resource or not before it runs it.
  
# So why the resource is being created? 

- That resource is GIL(Global Interpreter Lock), which must be acquired by the process. 
- So as soon as one thread is completed, it should be released for the use of another thread.  
- We can run multiple apps in the python, which means running a multiple processes, and that is fine 
  because each processes creates it's own GIL. Each process created its own thread. 
- But at the same time, they cannot be collaborated between processes easily. 
- It can be done but it is quite expensive, it requires a lot of computing power to communicate between 2 processes. 
- That's just how computers have been designed so that we can have separate resources in each process
  and they are completely separate entities.

# So what is the point of threads?
Because using threads is not free. It takes some computing power to remove them from the cores and put them back in
so when you have threads you can actually see your Python code become slightly slower. 
If they can not run at the same time, and also they can make your code slower. So what is the point of Threads?
- Let's say our python program does 2 things:
    1- complex mathematical operation -> that takes a long time as it has a complex calculation.
    2- asks use some input - entirely different thing. This can also take time as it will depend on user to input.

We can do
>> Single Thread
In which first complex calculation is done and then we will ask the the user for the input.

|-------------------------------complex calculation-----------------------||------------user input---------------------|
It shows how much time each thread is taking to perform.
                                            OR
                                            
|---------user input-------------||--------------------------------------complex calculation---------------------------|
                                            
This single thread is taking a reasonable amount of time overall.

So instead we can do 
>> Cooperative Multitasking
But we can remember only one thread can be run at a time.

1- first will ask the user to input and will release GIL to use by another thread in waiting
2- Then the GIL is passed for calculation, and there would be something that tells the when the user has enter.
3- And the GIL is released and it will passed to User input to cater and when it finishes execution, it will release GIL
4- And then again the GIL will pass to cater the complex calculation.
|U.I|                           |U.I|
    |----complex calculation----|   |-------------------------complex calculatio----------------------------|

5- So the overall time is reduced, as we have reduced the waiting time for the user to input.
6- Because now our threads are only running when there are things to do in the computer. When the user is waiting,
   or we are waiting for the user to type, or some data to come into a programme from some place
   we don't have to be waiting. We can be doing something else during that time.
   
Notice that this bottom set of rectangles would take slightly longer than just the addition of the user
and the mathematical calculation because of the threads communicating with one another, 
GIL being released, GIL being acquired, and being put in the core and then removed from the core. 
But overall it takes less time. 

$ Advantage of Threads in Python 
    - Reduces time.
    
- If all your threads are doing things in Python,if all your threads are using your CPU, your processor,
  multiple thread is not going to help you in Python. 
- Because Python doesn't do very well that running things in parallel.
- And the reason this works is because the OS is going to give priority to threads that are doing things.
- So in this case out mathematical calculation thread. So if a thread is waiting, it's going to run less frequently
  because the OS is going to realise there is a thread that wants to use the CPU, and there's a thread that doesn't.
- So it'd probably run the one that does a bit more often. So that it gets way more time on the CPU.
'''
'''
# GIL
- The Python Global Interpreter Lock or GIL, in simple words, is a mutex (or a lock) that allows only one thread 
  to hold the control of the Python interpreter.
'''