import time
from multiprocessing import Process

'''
# MultiProcessing
- It is running 2 codes in parallel.
- It is used when 
- So we can launch multiple processes with Python.
- We can have our main Python process that gets created when we launch our Python App.
- And we can ask our Python code to launch another process. When we do that, each process can have its own thread
  running in two separate cores.
- When we do that, each process can have its own thread running in two separate cores.
- So the two processes would be entirely separate from one another. As part of doing that it can also
  set up communication between the processes, and that communication is slow, but it can allow us to run through things
  actually at once in two separate cores.
'''


def ask_user():
    start = time.time()
    user_input = input("Enter your name: ")  # this is a blocking operation, for which thread will wait.
    greet = f"hello {user_input}"  # thread will not wait for this statement
    print(greet)  # thread will not wait for this operation.
    print(f"ask_user, {time.time() - start}")


def complex_calculation():
    start = time.time()
    print("Started calculating...")
    var = [x ** 2 for x in range(20000000)]
    print(f"complex_calculation, {time.time() - start}")


'''start = time.time()
ask_user()
complex_calculation()
print(f"Single thread total time: {time.time() - start}")  # some extra time is added,'''

process1 = Process(target=complex_calculation)
# now we will create process for ask_user()
process2 = Process(target=ask_user)
if __name__ == '__main__':
    process1.start()
    process2.start()

    #ask_user() # now we don't require this fn as we have created process for this fn.
    start = time.time()

    process1.join() # waiting for the process to get over.
    process2.join()

    print("Two process total time: ", time.time() - start)
'''
Output: when we have created 2 processes.
- We will get error while executing ask_user fn because the input fn doesn't have an access to this terminal.
- Remember the processes cannot share resources very easily. So it doesn't know where we're meant to be reading from
  when we tell it to finish, to finish by doing process2.join, it says okay we didn't type anything.
  There was nothing, there was no way for us to get the input. And also there's no way for us to type it.
'''
# we can use processes if we have multicore machine.
# we run the complex_calculation fn in both the process, which doesn't require input.

'''
process1 = Process(target=complex_calculation)
process2 = Process(target=complex_calculation)

if __name__ == '__main__':
    process1.start()
    process2.start()

    start = time.time()

    process1.join() # waiting for the process to get over.
    process2.join()
    
    print("Two process total time: ", time.time() - start)
    
# This is why you use multi processing when you need two things to run at the same time in the CPU.
'''

'''
but this is the reason why earlier on

you got your two lines in the same line.

They were accessing the console simultaneously,

but it was essentially, sorry, a separate entity.
'''