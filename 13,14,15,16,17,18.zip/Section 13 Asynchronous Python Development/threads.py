import time
from threading import Thread # this gives access to threads
# Whenever we create a thread, that's gonna go to the operating system and it's gonna ask the operating system
# to give us a new thread and the operating system is gonna be like, okay here you go, new thread,
# you can run whatever you want in it.

def ask_user():
    start = time.time()
    user_input = input("Enter you name: ") # this is a blocking operation, for which thread will wait.
    greet = f"hello {user_input}" # thread will not wait for this statement
    print(greet) # thread will not wait for this operation.
    print(f"ask_user, {time.time() - start}")

def complex_calculation():
    start = time.time()
    print("Started calculating...")
    var = [x ** 2 for x in range(20000000)]
    print(f"complex_calculation, {time.time() - start}")

start = time.time()
ask_user()
complex_calculation()
print(f"Single thread total time: {time.time() - start}") # some extra time is added,
# this is because the cursor to jump from one fn to another.

# we will not run the fn here, we will just the reference of the fn.
thread1 = Thread(target=complex_calculation)
thread2 = Thread(target=complex_calculation)

# So now 3 threads are running: thread1, thread2 and the main thread i.e.
# A thread which is responsible for running the other 2 threads.
start = time.time()

thread1.start()
thread2.start()

# Now all 3 threads would be running at the same time.
# So we will ask the main thread to let finish off the above 2 threads.
thread1.join()
thread2.join()

print(f"Two thread total time is: {time.time() - start}")

'''
Output:
- We can see that single threaded taken more time because until the user enters the input, 
  the thread won't get completed and the thread would be in a kind of blocked state.
- In multi threaded, however if user has taken a some amount of time to input, it won't affect the total execution time
  Because till the time user has input, the 1st thread will release its GIL and pass it to 2nd thread and as soon as
  user has input, the thread2 will release its GIL and give it to thread1 and there is no big calculation, 
  we are just passing string and thus reducing the waiting time. 
  And GIL will pass it to the thread2 for the its execution.
  So overall the total execution time would be less.   
'''
'''
- If we use complex_calculation fn in both the threads, then the overall execution time will be more.
  This is because they cannot run at the same time. So the OS was sort of giving a little bit of time to one
  then pulling it out and giving a little bit of time to the other, then pulling it out and going back to the first one,
  then going to the second one and so forth, switching between the two but all of them needed all that time in the CPU
  to calculate things. So in total, what you did is, you spread out the time that each one was running.  
  
- If we have run the 2 thread sequentially, it would have taken less time.
'''
# So if you are doing things that require the CPU all the time, don't use threads.
# It's pointless in Python.