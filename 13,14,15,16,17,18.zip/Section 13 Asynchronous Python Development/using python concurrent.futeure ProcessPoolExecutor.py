import time
#from threading import Thread  # this gives access to threads
from concurrent.futures import ProcessPoolExecutor


def ask_user():
    start = time.time()
    user_input = input("Enter you name: ")  # this is a blocking operation, for which thread will wait.
    greet = f"hello {user_input}"  # thread will not wait for this statement
    print(greet)  # thread will not wait for this operation.
    print(f"ask_user, {time.time() - start}")


def complex_calculation():
    start = time.time()
    print("Started calculating...")
    var = [x ** 2 for x in range(20000000)]
    print(f"complex_calculation, {time.time() - start}")

start = time.time()
if __name__ == '__main__':
    with ProcessPoolExecutor(max_workers=2) as pool:
        pool.submit(complex_calculation)
        pool.submit(complex_calculation)

print("ProcessPoolExecutor, ", {time.time()- start})
