def countdown(n):
    while n>0:
        yield n
        n -= 1

c1 = countdown(10)
c2 = countdown(20)

# Using generators is another way of achieving multitasking and doing multiple things at once in Python.
# But again, remember multitasking is doing things that look like they are happening at the same time,
# but they are really not. Parallelism is about doing things actually at the same time, and in Python
# we cannot do parallelism because of the GIL unless we launch multiple processes.

tasks = [countdown(10), countdown(5), countdown(20)]

while tasks:
    task = tasks[0] # countdown(10) will be fetched
    tasks.remove(task) # then it will be removed from the list
    try:
        x = next(task) # we will yield next value from the countdown(10)
        print(x) # we will print it
        tasks.append(task) # we will append countdown(10) to the end of the list and then countdown(5) will be fetched.
    except StopIteration: # when all the values are over for the particular instance we have created
        print("Tasks finished")
# So we can see that multiple tasks being running, but one at a time by handling the core of the OS.
# All 3 tasks has been collaborated to complete within the time.
# We can see how we can use yield in any circumstance to suspend a task temporarily
# and then bring it back at some point in the future.
# Of course, if we've got a task that doesn't yield, then you have a problem because that one
# is just gonna clog the CPU, and if we have a task that yields
# but it takes a very long time between one yield and another, that task is gonna take up a lot of time
# and the other task is not gonna have enough time.
# In that case, if we have a task that takes a long time to run, while the others take a very small amount of time
# to run, we could offload the work to a separate thread or to a separate process using,
# as we've seen already, the thread pool executor, or the process pool executor.

# And actually, calling next on a function and going back to a suspended function
# is cheaper than changing from one thread to another.