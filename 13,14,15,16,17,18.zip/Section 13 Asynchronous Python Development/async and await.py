from collections import deque
from types import coroutine

friends = deque(('Rolf', 'Jose', 'Charlie', 'Jen', 'Anna'))

@coroutine
def friend_upper():
    while friends:
        friend = friends.popleft().upper() # we will take the friend from the deque and then change it to upper case
        greeting = yield # it will suspend the fn until yield receives the value.
        print(f"{greeting} {friend}")

async def greet(g):
    print("Starting...")
    await g # it will wait for friend_upper fn to over but still greet fn will not be finished until coroutine is ended
    print("Ending....")

greeter = greet(friend_upper())
greeter.send(None) # priming the greeter generator.
greeter.send("Hello")
print("Hello World!, multitasking")
greeter.send('How are you, ')
# here we can see that coroutine has a loop and it will continue to run until the friend is empty.
# it is completed because we have gone through only 2 of the friends.
