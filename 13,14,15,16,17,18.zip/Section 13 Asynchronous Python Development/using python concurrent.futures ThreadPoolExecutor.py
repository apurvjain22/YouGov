import time
#from threading import Thread  # this gives access to threads
from concurrent.futures import ThreadPoolExecutor
'''
ThreadPoolExecutor is going to create a pool of threads that's just a bunch of threads with no target
and it's going to allow us to use that pool to execute jobs or in this case our functions.
'''


def ask_user():
    start = time.time()
    user_input = input("Enter you name: ")  # this is a blocking operation, for which thread will wait.
    greet = f"hello {user_input}"  # thread will not wait for this statement
    print(greet)  # thread will not wait for this operation.
    print(f"ask_user, {time.time() - start}")


def complex_calculation():
    start = time.time()
    print("Started calculating...")
    var = [x ** 2 for x in range(20000000)]
    print(f"complex_calculation, {time.time() - start}")


start = time.time()
ask_user()
complex_calculation()
print(f"Single thread total time: {time.time() - start}")  # some extra time is added,
# this is because the cursor to jump from one fn to another.

'''
# creates threads
thread1 = Thread(target=complex_calculation)
thread2 = Thread(target=ask_user)

start = time.time()

# starts threads
thread1.start()
thread2.start()

# waits them to finish
thread1.join()
thread2.join()

print(f"Two thread total time is: {time.time() - start}")

# so instead of creating a new threads every time, we will use, ThreadPoolExecutor
'''
start = time.time()
with ThreadPoolExecutor(max_workers=2) as pool:
    pool.submit(ask_user)
    pool.submit(complex_calculation)


# pool.shutdown() - we don't have to use, because we have used 'with' here.
print(f"ThreadPoolExecutor takes, {time.time() - start}")
'''
Again, this creates a pool of threads, a collection of threads and then we can submit a task to it,
and because we've used it with this with statement, all this does is it waits for the pool to finish.
'''
# ThreadPoolExecutor makes the code more simple and it will running the thread in asychronous manner.