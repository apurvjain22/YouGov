# receiving through yield
'''
def greet():
    friend = yield # whatever value is being passed to yield will assign ti friend
    print(f"Hello {friend}")

g = greet()
g.send(None) # priming the generator
# It runs the code right before the yield
g.send('Rolf') # then sending the value to yield.
# we get a StopIteration error because there is yield fn, which sort of looking for another value to yield,
# and as the value is finished, i.e. the end of the generator it will throw StopIteration error.
'''

from collections import deque

friends = deque(('Rolf', 'Jose', 'Charlie', 'Jen', 'Anna'))

def friend_upper():
    while friends:
        friend = friends.popleft().upper() # we will take the friend from the deque and then change it to upper case
        greeting = yield # it will suspend the fn until yield receives the value.
        print(f"{greeting} {friend}")

def greet(g):
    g.send(None) # bringing the friend_upper fn till yield. i.e. priming the generator
    while True:
        greeting = yield
        g.send(greeting)

greeter = greet(friend_upper())
greeter.send(None) # priming the greeter generator.
greeter.send("Hello")
print("Hello World!, multitasking")
greeter.send('How are you, ')
# we are multitasking three tasks all together.
# By the help of 'yield', we can see that how work gets divided.
# when you have generators that receive data, they're really no longer called generators
# because they're not generating anything.

# Now generators are receiving data and doing something with it.
# So from now onwards, this type of generator i.e. friend_upper() shall be known
# as a co-routine. And in Python, they're known as co-routines
# because they take in data, and they can be suspended, so that's a co-routine.