'''
# Atomic Operation
- An atomic operation is one that cannot be interrupted in the middle of it.
- So we cannot interrupt an atomic operation halfway through it by changing to a new thread.
'''
import time
import random
from threading import Thread

counter = 0

'''
def increment_counter():
    global counter
    counter += 1
    print(f"New counter value {counter}")
    print("---------------------")

'''
# running normally
'''for x in range(10):
    increment_counter()
'''
# So if we run the fn using thread.
'''
for x in range(10):
    t = Thread(target=increment_counter)
    t.start()
'''
'''
# Output Analysis:
- Here we are getting the output sequentially because till the time next thread should start 
- the first thread which was started at the beginning, it got finished.
- So we won't get to know that multiple threads are running.
'''

# so to know multiple threads are running we will use Fuzzing

def increment_counter():
    global counter
    time.sleep(random.random())
    counter += 1
    time.sleep(random.random())
    print(f"New counter value {counter}")
    time.sleep(random.random())
    print("---------------------")

for x in range(10):
    t = Thread(target=increment_counter)
    time.sleep(random.random())
    t.start()


'''
Output Analysis:
- We are not getting an output in sequential manner, after applying the sleep functionality.
- So what happening is, one of them started then it encountered random sleep
  but by that time another one had maybe started and encountered another random sleep.
- We've got a bunch of things running at the same time on your computer and these threads are jumping
  in and out of course very quickly.
- Then you may start encountering problems like this one.
- Especially if you threads are, really only if your threads are accessing or modifying shared state.
  Here the variable is the shared state, these threads have half that variable shared amongst them.   
'''