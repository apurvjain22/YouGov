def countdown(n):
    while n>0:
        yield n # the fn will get suspended after yielding and it will resume once it will be called again
        n -= 1

c1 = countdown(10)
# print(next(c1))
# print(next(c1))
# So generator is very similar to a thread, 'cause the thread can at any point be suspended or removed from a core
# and then it can be brought back and it continues running where it's left off.
# So the generator actually behaves fairly similar to a thread in that when we arrive at a yield
# we're removing it from the core, then when we press next, we're sort of bringing it back and it continues running.

c2 = countdown(20)
print(next(c1))
print(next(c2))
print(next(c1))
print(next(c2))

# This is an example of slow multi-threading but without threads.
# we have got 2 threads, passing one to another.
# We cannot run 2 threads at the same time in Python, but we can slice their time on the CPU
# quickly enough that it looks like they're running at the same time.
# Asynchronous development in Python is built around this generator.