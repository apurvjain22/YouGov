import time
import random
import queue

from threading import Thread

counter = 0
job_queue = queue.Queue() # things have to be printed out
counter_queue = queue.Queue() # amounts by which to increase

def increment_counter():
    global counter
    while True:
        increment = counter_queue.get() # this will wait until it gets the value and then locks it.
        # If 10 threads are calling this queue, then only 1 will be access this thread at a time and other 9 will wait.
        time.sleep(random.random())
        old_counter = counter
        time.sleep(random.random())
        counter = counter + increment
        time.sleep(random.random())
        job_queue.put((f"New counter value is {counter}", "---------------"))
        time.sleep(random.random())
        counter_queue.task_done() # this unlocks the queue.
        # so now another thread could go back and get something if they wanted.

Thread(target=increment_counter, daemon=True).start() # by daemon=True, it will run forever until it finds an error.

def printer_manager():
    while True:
        for line in job_queue.get():
            print(line)
            time.sleep(random.random())
        job_queue.task_done()

Thread(target=printer_manager, daemon=True).start()
# so the printer manager and the increment manager are gonna run continuously because of that daemon flag.


def increment_counter():
    counter_queue.put(1) # putting 1 value in the counter_queue.
    # So that increment variable can receive a value.
    time.sleep(random.random())

# made 10 worker threads
worker_threads = [Thread(target=increment_counter) for thread in range(10)]

# starting those threads
for thread in worker_threads:
    time.sleep(random.random())
    thread.start()
# we will wait for the threads to be finish in worker_threads.
for thread in worker_threads:
    thread.join()

# At the end we're gonna wait for the counter queue to finish, to not have anything left in the queue
# and the job queue to also not have anything left in it.
counter_queue.join()
job_queue.join()
# Notice how we are joining the queues, not the daemon threads because this daemon threads are never gonna stop,
# they're always gonna be running. So we are joining on the queue.
# And when the queue are empty, we will be done.


# queue should be used for multithreading purpose