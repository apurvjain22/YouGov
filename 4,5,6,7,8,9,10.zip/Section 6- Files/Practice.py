import numpy as np
import pandas as pd
from os import path
from PIL import Image
from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator
import matplotlib.pyplot as plt
from nltk.corpus import stopwords

df = pd.read_csv("C:\\Users\\apurv.jain\\Documents\\Python\\Intellx\\Anil\\wine-reviews\\winemag-data-130k-v2.csv")
text = "".join(review for review in df.description) # combining all the reviews into ne string
wine_mask = np.array(Image.open("C:\\Users\\apurv.jain\\Documents\\Python\\Intellx\\Anil\\wine_mask.png")) # Convert the image to a numeric representation (a 3D array)
print(wine_mask)

# function to assign the 255 value to mask the image variable from 0.
def transform_format(val):
    if val == 0:
        return 255
    else:
        return val

transformed_wine_mask = np.ndarray((wine_mask.shape[0],wine_mask.shape[1]), np.int32) # we are creating new new mask variable to make the background white
# shape tells us the size of an array and returns a tuple of integers.


#below we are initializing the new mask variable to 255.
for i in range(len(wine_mask)):
    transformed_wine_mask[i] = list(map(transform_format, wine_mask[i]))
print(transformed_wine_mask)

wc = WordCloud(background_color="black", max_words=1000, mask=transformed_wine_mask,
               stopwords=stopwords, contour_width=1, contour_color='firebrick')

# Generate a wordcloud
wc.generate(text)

# store to file
wc.to_file("C:\\Users\\apurv.jain\\Documents\\Python\\Intellx\\Anil\\wine.png")
wc.to_image()

'''# show
plt.figure(figsize=[20,10])
plt.imshow(wc, interpolation='bilinear')
plt.axis("off")
plt.show()'''