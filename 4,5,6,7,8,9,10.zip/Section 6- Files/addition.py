class Addition:
    @classmethod
    def add(cls,num1, num2):
        return num1 + num2