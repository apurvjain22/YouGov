import csv

path = "C:\\Users\\apurv.jain\\Documents\\Python\\Intellx\\Anil\\wine-reviews\\winemag-data-130k-v2.csv"

with open(path, 'r', encoding="UTF8") as file:
    csv_reader = csv.reader(file, delimiter=',')
    contents = []
    for row in csv_reader:
        contents.append(row[2])

print(contents)
text = "".join(review for review in contents) # combining all the reviews into ne string
print(text)