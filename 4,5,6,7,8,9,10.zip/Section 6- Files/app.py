import utils.file_operations #here we are importing module and app.py is a script
#if we want we can import a selected  functions/methods from the module.
from utils.file_operations import save_to_file, read_file
#here what above importing function doing is going to the file operations module and running the code, i.e. here it will define not run all the functions


save_to_file('Rolf','Data.txt')
print(read_file('Data.txt'))
#here the files are open and close automatically

