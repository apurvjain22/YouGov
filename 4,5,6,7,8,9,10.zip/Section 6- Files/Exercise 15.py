import json, csv
file_csv = open('csv_file.txt','r')
reader = csv.DictReader(file_csv, fieldnames=['club','city','country']) #using the DictReader() of csv module to join both the data
#reader will have the following data
#OrderedDict([('club', 'Manchester United'), ('city', 'Manchester'), ('country', 'UK')])
#OrderedDict([('club', 'Real Madrid'), ('city', 'Madrid'), ('country', 'Spain')])
#OrderedDict([('club', 'Juventus'), ('city', 'Turin'), ('country', 'Italy')])

csv_read = [line for line in reader]
file_csv.close()

json_file = open('json_file.txt','w')
json.dump(csv_read,json_file)
json_file.close()

#other way
import json

json_list = []
file = open("csv_file.txt", "r")
file_contents = [line.strip().split(',') for line in file.readlines()]

fieldnames = ["club", "city", "country"]

for content in file_contents:
    dictionary = dict(zip(fieldnames, content))
    json_list.append(dictionary)
file.close()

json_file = open('json_file.txt', 'w')
json.dump(json_list, json_file)
json_file.close()

#jose way
import json

json_list = []  # store the converted json data for each line
csv_file = open('csv_file.txt', 'r')

for line in csv_file.readlines():
    club, city, country = line.strip().split(',')  # first get rid of the \n and then split with ','
    data = {
        'club': club,
        'city': city,
        'country': country
    }
    json_list.append(data)

csv_file.close()

json_file = open('json_file.txt', 'w')
json.dump(json_list, json_file)  # write json data to a file
json_file.close()