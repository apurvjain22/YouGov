class Employee:
    increment = 1.5  # class variable

    def __init__(self, fname, lname, salary):  # constructor
        self.fname = fname  # all 3 are instance variable
        self.lname = lname
        self.salary = salary

    def increase(self):
        self.salary = self.salary * Employee.increment

    @classmethod
    def change_increment(cls, amount):
        cls.increment = amount

    @classmethod
    def from_str(cls, emp_string):
        fname, lname, salary = emp_string.split("-")
        return cls(fname, lname, salary)


class Programmer(
    Employee):  # Programmer is overriding Employee class, which means it will have all the attributes + methods
    def __init__(self, fname, lname, salary, proglang, exp):
        super(Programmer, self).__init__(fname, lname, salary) #equivalent to below line.
        # super().__init__(fname, lname, salary)
        self.proglang = proglang
        self.exp = exp

    def increase(self):  # overriding Employee increase() in Programmers class
        self.salary = int(self.salary * (self.increment + 0.2))
        return self.salary


apurv = Programmer('Apurv', "Jain", 42500, "Python", 4)
print(apurv.fname)
print(apurv.increase())
