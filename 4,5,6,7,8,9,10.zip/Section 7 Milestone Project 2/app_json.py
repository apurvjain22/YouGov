# app.py is an interface created for the user
import utils.Database_json
from os import path # importing to check whether the file exists or not
print('Your book collections!')
user_choice = '''
Please enter from the following options provided below.
- 'a' to add the book
- 'l' to list all the books
- 'r' to mark the book as read
- 'd' to delete the book
- 'q' to quit
Enter: '''


def menu():
    # checking the books.txt file exists or not.
    if not path.exists('books.json'):
        utils.Database_json.create_book()
    user_input = input(user_choice)
    while user_input != 'q' or user_input != 'Q':
        if user_input == 'a' or user_input == 'A':
            add_books()
        elif user_input == 'l' or user_input == 'L':
            list_all_books()
        elif user_input == 'r' or user_input == 'R':
            status_change()
        elif user_input == 'd' or user_input == 'D':
            delete_book()
        user_input = input(user_choice)
    total_count = count()
    print(f'You have total {total_count} books in your collection')
    print('Thanks for visiting the online book store!')


# we could also write the fns in the database directly instead of writing it here.
# Because decoupling is a good practice to follow.
# Suppose if there is a need of connecting to another database, then again we have to write everything from scratch.
# And also if there is an error in the file, then we could easily traceback the error rather then having all the code
# in the same place and it would be difficult to traceback the error.

# we have perfectly decoupled our business logic(app.py) from our database

# ------------------------------------------------------------------------------------------------------------------------------------------


# adding the books
def add_books():
    bookname = input('enter bookname: ').title()
    authorname = input('enter author name: ').title()
    utils.Database_json.add_book(bookname, authorname)
    print('Your book got added')


# getting all the books from the database
def list_all_books():
    books = utils.Database_json.list_books()
    if isinstance(books, str):
        print(books)
    else:
        for book in books:
            read = 'read' if book['read'] == True else "not read"
            print(f"{book['name']} by author {book['author']} is {read} by you.")


# changing the status of the book if read
def status_change():
    bookname = input('Enter bookname you have read: ').title()
    utils.Database_json.change_the_status(bookname)
    print('Books status got changed')


# deleting the book from the database
def delete_book():
    bookname = input('Enter book name which you want to delete: ')
    utils.Database_json.delete_book(bookname)
    print('Book got deleted from the collection')


def count():
    book = utils.Database_json.list_books()
    return len(book)

# calling the fn
menu()
