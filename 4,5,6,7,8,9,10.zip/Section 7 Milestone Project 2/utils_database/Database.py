import sqlite3
# whenever we are using type hinting we have to import it from the 'typing' module
from typing import List, Dict, Union
from utils_database.database_connection import DatabaseConnection

'''
storing and retrieving data from database
'''


def create_book_table() -> None:
    with DatabaseConnection('data.db') as connection:
        cursor = connection.cursor()

    # it would be string
        cursor.execute('CREATE TABLE IF NOT EXISTS books(name TEXT, author TEXT PRIMARY KEY, read INTEGER)')  # name would be unique here
    # whatever will be the main column signifying as an identifier we will be using it as a primary key
    # primary key would be unique and also improves the performance


def add_book(name: str, author: str) -> None:
    try:
        with DatabaseConnection('data.db') as connection:
            cursor = connection.cursor()

    # through below there is a chance of injecting a sequel injection attack
    # if we have a direct replacement of the string into a query it opens up this path of attack.
    # This is called interpolation.
    #cursor.execute(f'INSERT INTO books VALUES("{name}", "{author}", 0)')# we are keeping "[name}" to tell this a string else it will consider a table name

    # below is the correct way to insert the data into db
            cursor.execute('INSERT INTO books VALUES (?, ?, 0)', (name, author)) # make sure the variables passed in the tuple
            print(f"Book {name} by author {author} is added in the collections.")
    except sqlite3.IntegrityError:
        print(f"Book {name} by author {author} is already there in the collections.")


def get_all_books() -> List[Dict[str, Union[str, int]]]:# telling keys are in str and values is a mixture of string and int.  We can also define in a variable and pass the variable into list.
    with DatabaseConnection('data.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM  books')
    #books = cursor.fetchall() # fetch all the rows. And it will return list of tuples [(name, author, read), (name, author, read)]
        books = [{'name': row[0], 'author':row[1], 'read': row[2]} for row in cursor.fetchall()] #making a list of dict by using list comprehension
            # we haven't anything write so no need of commit statement
            # connection.commit()
    if books:
        return books
    else:
         print('No books found. Please add books in the book collections.')


def mark_book_as_read(name: str, author: str) -> None:
     with DatabaseConnection('data.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT name, author FROM books WHERE name=? and author=?', (name,author))

        if bool(len(cursor.fetchall()) == 0): # checking if the list is empty or not
            print('No books are there in the collections.')
        elif bool(name in book for book in cursor.fetchall()) and bool(author in book for book in cursor.fetchall()):
            # (any(name, author in book for book in cursor.fetchall())): # any() will check each element in the tuple
            cursor.execute('UPDATE books SET read = 1 WHERE name=?', (name,))
            print(f'The status of {name} book is now changed.')
        else:
            print(f'No {name} book is found in the collections.')


def delete_book(name: str, author: str) -> None:
    with DatabaseConnection('data.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT name FROM books WHERE name=? and author=?', (name,author))

        if len(cursor.fetchall()) == 0:
            print("No books are there in your collections.")
        elif bool(name in book for book in cursor.fetchall()) and bool(author in book for book in cursor.fetchall()):
            cursor.execute('DELETE FROM books WHERE name=? and author=?', (name,author))
            print(f"The book {name} by {author} is deleted from the collections.")
        else:
            print(f'No {name} book is found in your collection.')
