import json
"""
storing and retrieving the data from json file
[
    {
        'name': 'Macbeth'
        'author: 'Shakespeare'
        'read': True
    }
]
"""
book_file = 'books.json'

def create_book():
    with open(book_file, 'w') as file:
        json.dump([], file)


def list_books():
    with open(book_file,'r') as file:
        print(" ")
        if file.seek(2) != '[]':
            return 'No books are there in your collections'
        else:
            return json.load(file)

def _save_all_books(books):
    with open(book_file,'w') as file:
        json.dump(books, file)


def add_book(bookname, author):
    books = list_books()
    books.append({'name': bookname, 'author': author, 'read': False})
    _save_all_books(books)


# changing the read status of the book in the file
def change_the_status(bookname):
    books = list_books()
    print('before', books)
    for book in books:

        if book['name'] == bookname:
            book['read'] = True
            print('After ',books)
    _save_all_books(books)


# deleting the book from the file.
def delete_book(bookname):
    books = list_books()
    if bookname in books:
        for book in books:
            if book['name'] == bookname.title():
                books.remove(book)
    else:
        print('wrong book entered')
    _save_all_books(books)


