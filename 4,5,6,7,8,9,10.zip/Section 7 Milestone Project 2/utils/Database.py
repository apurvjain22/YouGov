#So, this database.py here, is what's called an interface in programming.
# An interface between our business logic, what a programme is supposed to do(app.py),
# and the storage which in this case would be a database, sorry a file,


'''
storing and retrieving books from a csv file
Format of the csv file:

name, author, read
'''


# creating an empty book
def create_book():
    with open('books.txt','w'):
        pass #just to make sure te file is there

#adding books into books.txt file
def add_book(bookname, author, read = False):
    with open('books.txt','a') as book_csv: #appending the file so that every book could be added at the last
        book_csv.write('{}, {}, {}\n'.format(bookname.title(),author.title(),read))


#listing down all the books using file
def list_books():
    #print("Your Book Collection!")
    with open('books.txt','r') as read_csv:
        list_books = [line.strip().split(',') for line in read_csv.readlines()]

        # list of dict comprehension
        books = [{'name': line[0], 'author': line[1], 'read': line[2]} for line in list_books]
        return books


#It tells other coder that this is a 'private fn', it shouldn't be called other than this file.
#Python doesn't have the concept of a private function, so, other people form outside of the file
#can still call this function if they want, but the naming conventions in Python says that if a function has a underscore in front,
#you should probably not call it.

# saving all the books after changing the status and deleting the book all over again into the files.
def _save_all_books(books):
    with open('books.txt', 'w') as book_write:
        for book in books:
            book_write.write(f"{book['name']},{book['author']},{book['read']}\n")

#changing the read status of the book in the file
def change_the_status(bookname):
    books = list_books()
    for book in books:
        if book['name'] == bookname.title():
            book['read'] = True
    _save_all_books(books)

#deleting the book from the file.
def delete_book(bookname):
    books = list_books()
    for book in books:
        if book['name'] == bookname.title():
            books.remove(book)
    _save_all_books(books)