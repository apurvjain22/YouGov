# app.py is an interface created for the user
import utils.Database
from os import path # importing to check whether the file exists or not
print('Your book collections!')
user_choice = '''
Please enter from the following options provided below.
- 'a' to add the book
- 'l' to list all the books
- 'r' to mark the book as read
- 'd' to delete the book
- 'q' to quit
Enter: '''


def menu():
    user_input = input(user_choice)
    if str(path.exists('books.txt')): #checking the books.txt file exists or not.
        print('Your Book collection is empty!')
        utils.Database.create_book_table()
    while user_input != 'q':
        if user_input == 'a':
            add_books()
        elif user_input == 'l':
            list_all_books()
        elif user_input == 'r':
            status_change()
        elif user_input == 'd':
            delete_book()
        user_input = input(user_choice)
    print('Thanks for visiting the online book store!')


# we could also write the fns in the database directly instead of writing it here.
# Because decoupling is a good practice to follow.
# Suppose if there is a need of connecting to another database, then again we have to write everything from scratch.
# And also if there is an error in the file, then we could easily traceback the error rather then having all the code
# in the same place and it would be difficult to traceback the error.

# we have perfectly decoupled our business logic(app.py) from our database

# ------------------------------------------------------------------------------------------------------------------------------------------


# adding the books
def add_books():
    bookname = input('enter bookname: ')
    authorname = input('enter author name: ')
    utils.Database.add_book(bookname, authorname)


# getting all the books from the database
def list_all_books():
    for book in utils.Database.list_books():
        read = 'read' if book['read'] == 'True' else "not read"
        print(f"{book['name']} by author{book['author']} is {read} by you.")


# changing the status of the book if read
def status_change():
    bookname = input('Enter bookname you have read: ')
    utils.Database.change_the_status(bookname)


# deleting the book from the database
def delete_book():
    bookname = input('Enter book name which you want to delete: ')
    utils.Database.delete_book(bookname)


# calling the fn
menu()
