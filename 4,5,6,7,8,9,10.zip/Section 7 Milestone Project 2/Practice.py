import utils.Database_json
import sqlite3
from utils_database.database_connection import DatabaseConnection


def create_book_table() -> None:
    with DatabaseConnection('data.db') as connection:
        cursor = connection.cursor()

    # it would be string
        cursor.execute('CREATE TABLE IF NOT EXISTS books(name text primary key, author text, read integer)')  # name would be unique here
    # whatever will be the main column signifying as an identifier we will be using it as a primary key
    # primary key would be unique and also improves the performance
        #cursor.execute('INSERT INTO books ')
        cursor.execute('SELECT ROW_NUMBER() OVER (ORDER BY name), name, author, read FROM books')
        books = [{'row_wid':row[0], 'name': row[1], 'author':row[2], 'read': row[3]} for row in cursor.fetchall()]

        cursor = connection.cursor()

        cursor.execute('SELECT name, author FROM books WHERE name=? and author=?', (name, author))

        if (any((name, author) in book for book in cursor.fetchall())):  # any() will check each element in the tuple
            cursor.execute('UPDATE books SET read = 1 WHERE name=?', (name,))
            print(f'The status of {name} book is now changed.')
        else:
            print(f'No {name} book is found in your collection.')
        if books:
            print(books)
        else:
            print("no books")

create_book_table()
