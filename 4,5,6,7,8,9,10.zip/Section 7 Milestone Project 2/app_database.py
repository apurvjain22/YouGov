import utils_database.Database
from os import path # importing to check whether the file exists or not
print('Welcome to the book collections')
user_choice = '''
Please enter from the following options provided below.
- 'a' to add the book
- 'l' to list all the books
- 'r' to mark the book as read
- 'd' to delete the book
- 'q' to quit
Enter: '''


def menu():
    utils_database.Database.create_book_table()
    user_input = input(user_choice)

    while user_input:
        if user_input == 'a' or user_input == 'A':
            add_books()
        elif user_input == 'l' or user_input == 'L':
            list_all_books()
        elif user_input == 'r' or user_input == 'R':
            status_change()
        elif user_input == 'd' or user_input == 'D':
            delete_book()
        elif user_input == 'q' or user_input == 'Q':
            print('Thanks for visiting the book collections!')
            break
        else:
            print("Wrong choice entered!")
        user_input = input(user_choice)




# adding the books
def add_books():
    bookname = input('enter bookname: ')
    author = input('enter author name: ')

    utils_database.Database.add_book(bookname.title(), author.title())


# getting all the books from the database
def list_all_books() :
    try:
        for book in utils_database.Database.get_all_books():
            read = 'read' if book['read'] == 1 else "not read"
            print(f"{book['name']} by author {book['author']} is {read} by you.")
    except TypeError:
        pass


# changing the status of the book if read
def status_change():
    bookname = input('Enter bookname you have read: ')
    author = input('Enter author name: ')

    utils_database.Database.mark_book_as_read(bookname.title(), author.title())


# deleting the book from the database
def delete_book():
    bookname = input('Enter book name which you want to delete: ')
    author = input('Enter author name: ')

    utils_database.Database.delete_book(bookname.title(), author.title())


# calling the fn
menu()
