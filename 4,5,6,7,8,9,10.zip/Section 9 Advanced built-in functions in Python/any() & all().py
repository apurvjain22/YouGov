# any()
    # it takes an iterable and returns True if any of its elements evaluates to True

friends = [
  {
    'name': 'Rolf',
    'location': 'Washington, D.C.'
  },
  {
    'name': 'Anna',
    'location': 'San Francisco'
  },
  {
    'name': 'Charlie',
    'location': 'San Francisco'
  },
  {
    'name': 'Jose',
    'location': 'San Francisco'
  },
]

your_location = input('Where are you right now? ')
friends_nearby = [friend for friend in friends if friend['location'] == your_location]

if any(friends_nearby): #evaluates to True if any one of the friends gets located
  print('You are not alone!')

# Some values always evaluate to `False`:
    # `0`
    # `None`
    # `[]`
    # `()`
    # `{}`
    # `False`


# all()
    # it also takes an iterable and returns True if all the elements evaluates to True.

print(all([1,2,3,4,5])) # evaluates to True as all the elements are true
print(all([0,1,2,3,4,5])) #evaluates to False as not all the elements in the list are true

