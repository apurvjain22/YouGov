# Iterable
    # It is an object which has an __iter__().
    # this __iter__() method tells Python that we want to be able to iterate over this iterable.

class FirstHundredGenerator:
    def __init__(self):
        self.number = 0


    def __next__(self): # by this we can call next() fn
        if self.number < 100:
            current = self.number
            self.number += 1
            return current
        else:
            raise StopIteration() # we reach the end of the iteration

class FirstHundredIterable:
    def __iter__(self):
        return FirstHundredGenerator() # returning an iterator object



# Iterator is a mechanism in python which iterates over iterables.
# But to iterate over iterables, we have to make the iterable as iterator.


# print(sum(FirstHundredIterable()))
# for i in FirstHundredIterable():
    #print(i)

# All generators are Iterators, this can also be called as generator.
# As FirstHundredIterable is returning a current object and the purpose of self is also returning the current object.
# So instead of creating a separate class as FirstHundredIterable, we can use __iter__() method inside a FirstHundredGenerator class.
# iter() is returning the current object

class FirstHundredGenerator:
    def __init__(self):
        self.number = 0


    def __next__(self): # by this we can call next() fn
        if self.number < 100:
            current = self.number
            self.number += 1
            return current
        else:
            raise StopIteration() # we reach the end of the iteration


    def __iter__(self):
        return self # returning self will tell us that it is returning the current object as self has the dunder next method.
                    # Iterable return the iterator using the iterator method.


print(sum(FirstHundredGenerator()))
# So we can do that from the iterator itself as well, since self is always an iterator,
# because self is the object that has this dunder __next__() method.

class AnotherIterable:
    def __init__(self):
        self.cars = ['Fiesta','Focus']


    def __getitem__(self, i):
        return self.cars[i]


for car in AnotherIterable():
    print(car)

# In Python you can have your iterables defined either by using a
    # __iter__() method that returns an iterable,
    # __getitem__().
# Both of these are iterables and you can use for loops, __sum__(), and __list__() in them.

# Iterator - used to get the next value.
# Iterable - used to go over all the values of the iterator.

my_numbers_gen = (x for x in [1,2,3,4,5]) # generator comprehension
print(next(my_numbers_gen))


# All iterators are not iterables:
# because an Iterator needs to implement the __next__ method,
# and an Iterable only needs to return an Iterator in its __iter__() method