# Filter Fn
    # syntax- filter(function, itearble)
    #

def starts_with_r(friend):
    return friend.startswith('R')

friends = ['Rolf', 'Jose', 'Randy', 'Anna', 'Mary']
start_with_r = filter(starts_with_r, friends) # arg1: fn that returns True/False

# Note: filter returns a generator.
print(start_with_r) # So it will return the generator object

print(next(start_with_r)) # we have to use next to get the value from the generator
print(list(start_with_r)) # i.e. why in the list only 'Randy' is being there as Rolf has been used.
print(next(start_with_r)) # empty list will return as no values are there in generators to fetch.

# So instead of creating a func starts_with_r, we could also use lambda fn.
# 1 - lambda fn
friends = ['Rolf', 'Jose', 'Randy', 'Anna', 'Mary']
start_with_r = filter(lambda x : x.startswith('R'), friends) #lambda will return True/False
print(next(start_with_r)) #'Rolf'

# 2 - generator fn - identical to lambda fn
another_starts_with_r = (f for f in friends if f.startswith('R'))

#

# Creating a custom filter
def my_custom_filter(func, iterable): # func- lambda, iterable- freinds list
    for i in iterable:
        if func(i): #it will go to the lambda func and check whether the name starts with R or not
            yield i


start_with_r = my_custom_filter(lambda x : x.startswith('R'), friends)


# Python takes care of managing of data and sending data from one place to another
# and yield is extremely powerful because it lets you stop and generate the values
# one by one without having to store them all in memory at the same time.