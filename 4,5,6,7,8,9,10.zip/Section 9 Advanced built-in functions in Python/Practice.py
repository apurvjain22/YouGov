class Sentence:
    def __init__(self, word):
        self.word = 'This is a sentence'
        self.sentence = self.word.split()


    def __iter__(self):
        return self

    def __next__(self):
        for i in range(len(self.word)):
            return i

#my_sentence = Sentence
#print(next(my_sentence))

print(bool(-0.0))