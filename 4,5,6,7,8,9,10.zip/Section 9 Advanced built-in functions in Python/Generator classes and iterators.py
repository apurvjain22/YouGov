# Class Based Generator

class FirstHundredGenerator:
    def __init__(self):
        self.number = 0


    def __next__(self): # by this we can call next() fn
        if self.number < 100:
            current = self.number
            self.number += 1
            return current
        else:
            raise StopIteration() # we reach the end of the iteration

my_gen = FirstHundredGenerator()
print(next(my_gen))
print(next(my_gen))
# here it is not generating all 100 numbers at once, it is generating a number when the method is called.
# all objects that have dunder next method are called iterators.
# All generators are called as iterators but not vice versa.
'''
class FirstFiveIterator:
    def __init__(self):
        self.number = [1,2,3,4,5]
        self.i = 0


    def __next__(self):
        if self.i < len(self.number):
            current = self.number[self.i]
            self.i += 1
            return current
        else:
        raise StopIteration()
'''
# Above, we are not generating the numbers but we are returning them from a lists
# So not all iterators have to be generators
'''
## Iterators
- Iterators are those objects that have a dunder next method. You can call next on them.

'''
for i in my_gen():
    print(i)

# It will throw a error as my_gen is an iterator not an iterabble.
# Iterator means we can call the next function on it and it will give us the new value.
# we can iterate over a iterable.
# But an iterator and an iterable are different things.
# We can iterate over an iterable, and the iterator is used to get the next value
# from a sequence or from generated values.
# So what we've got ourselves here is an iterator not an iterable.