# Map Fn
    # It takes the iterable and output a new iterable, where each element has been modified according to some fns.
    # syntax - map(func, iterable)

friends = ['Rolf', 'Jose', 'Randy', 'Anna', 'Mary']
friends_lower = map(lambda x : x.lower(), friends)
# x is a parameter which is taking its value from friends list and then performing the lower case operation on each element.

# Note: map also returns a generator.
print(next(friends_lower)) # fetching values by using next as it is a generator

friends_lower = [friend.lower() for friend in friends] # list comprehension
friends_lower = (friend.lower() for friend in friends) # generator comprehension

# generator comprehension should be used more likely unless we need all of them to be in a list.

# When should we use map?
    # when the people in your team, the people you are working with,
    # are accustomed to using map, that's very popular in other programming languages,
    # or when you're working with other programming languages
    # at the same time, and you want to keep everything consistent,
    # or when you think its gonna be more readable because some of the functions
    # you've got defined earlier on you can use without having to create the new lambda function.

# Another example where we may use map instead of filter.

class User:
    def __init__(self, username, password):
        self.username = username
        self.password = password

    @classmethod
    def from_dict(cls, data):
        return cls(data['username'], data['password'])


users = [
    {'username': 'rolf', 'password': '123'}
    {'username': 'Apurv', 'password': 'password123'}
]

users = [User.from_dict(user) for user in User] # here we are creating an extra user variable
users = map(User.from_dict(), users) # more elegant




