#Generator Function

# It is a special fn which remembers the state it's in between executions and whenever it is called again, it will give the value just next to the previous one.
# The fn remembers where it stops.
# Example:
def hundred_numbers(): #generator fn
    i = 0
    while i<100: # generating hundred numbers
        yield i # will return a generator value
        i += 1

# print(hundred_numbers()) # it will return the generator object


g = hundred_numbers()
print(next(g)) # next is a built-in fn that affects the generators and it tell to go upto the yield.
print(next(g))

# Output:
# 0 - Here the output would 0 and the generator function will get destroyed until and unless it is called again.
# 1 - we would get 1 if we call again inbuilt generator next again.

# the fn remembers where it stops and whenever we call it will resume where it stops

print(list(g)) # generated a list of the generator and it will give the value from where it stopped.
# It does not store the lists of 100 numbers at once, so it also won't consume the computers memory.
# As you need you can call and the generator will fetch a data and we can perform some actions on it.