import re

email = 'jain.11apurv@gmail.com'
expression = '[A-z\.0-9]+' # matching characters followed by dot followed by numbers

matches = re.findall(expression,email) # matches all expression in email
print(matches)

name = matches[0]
domain = matches[1]
print(f'{name}')
print(f'{domain}')

# we can also use the split fn on '@' character.
parts = email.split('@')
name = parts[0]
domain = parts[1]
print(name)
print(domain)

print('Using Search')

price = 'Price: $18,899.90'
expr = '[A-z]*: \$([0-9,]*\.[0-9]*)'
matches = re.search(expr, price)
print(matches.group(0))
print(matches.group(1)) # extracting a particular thing from where we were extracting.

price_without_comma = matches.group(1).replace(',', '')
price_number = float(price_without_comma)
print(price_number)
