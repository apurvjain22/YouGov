accounts = {
    'checking': 1958.00,
    'savings': 4000.00
}


def add_balance(amount: float, name: str = 'checking') -> float:  # doing type hinting.
    '''
    fn to update the balance of an account and return the new balance 
    '''
    accounts[name] += amount
    return accounts[name]


add_balance(500.00, 'savings')
print(accounts['savings'])

# we have already provided a default value for the name parameter.
# It tells that if we are not providing the 'name' it will take the default value.
# The parameter which have a default value has to be passed at the end like 'name' parameter has been passed
# else it will give a syntax error.
