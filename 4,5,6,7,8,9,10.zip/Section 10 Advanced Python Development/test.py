if 0:
    print("APurv")
else:
    print("No")