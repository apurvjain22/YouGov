# whenever any object is created, a memory loc has been assigned to it which would be there in RAM.
# to see the memory address of any object, it can be seen as print(id(object_name)).
# if we have 2 variable with the same name and its content is also same, then its id would be still be different.

friends_last_seen = {
    'Rolf': 31,
    'Jen': 1,
    'Anne': 7
}
print(id(friends_last_seen))

friends_last_seen['Rolf'] = 0  # friends_last_seen.__setitem__(self, 'Rolf') -> mutating/modifying a self object i.e. friends_last_seen

print(id(friends_last_seen)) # will give the same memory location, as we are only mutating the dict

my_int = 5 # 5 can not be changed, it is 5
print(id(my_int)) # returns a memory location
my_int = my_int + 1 # we are changing the previous value of integer.
print(id(my_int)) # will return the different memory location, as we are not mutating but creating a new integer.
# Hence integer is a immutable.

'''
# Immutable objects
integers - all fns return new int objects
floats
strings
tuples

# Mutable objects
lists

'''
print('Another Example')
my_int = 5
print(id(my_int))
# whats happening in the background when we are adding a number in an integer
my_int = my_int + 1 # my_int.__add__(self, 1) -> it will return self.value + 1, which will give new integer value
print(id(my_int))
my_int += 1 # my_int.__iadd__(). iadd used to modify the objects
# but integer is a immutable object and by adding anything to integer the value will get change and so is the mem loc
print(id(my_int))

# all 3 will result in different memory loc
