# And the time module is used to deal just with times.
# So whenever you're running some code, you can measure the start time and the end time to calculate.

import time

def powers(limit):
    return [x**2 for x in range(limit)]

start = time.time()
p = powers(5000000)
end = time.time()
print(end - start) # checking how much time list comprehension takes

# created a measure_time func
def measure_time(func):
    start = time.time()
    func()
    end = time.time()
    print(end - start)

def power(limit):
    return [x**2 for x in range(limit)]

measure_time(lambda : power(5000))

# timeit
#   - This module provides a simple way to time small bits of Python code

import timeit

print(timeit.timeit("[x**2 for x in range(10)]"))
print(timeit.timeit("map(lambda x: x**2, range(10))"))

# this tells that map is faster than list comprehension