'''
Basic understanding of logging
'''
import logging

logging.basicConfig(
    filename='logging_file.txt', # if filename is not given than it will print in the output console itself.
    # filemode= 'w', # by default the mode is 'append'
    format='%(asctime)s %(name)s - %(funcName)s %(levelname)s - %(lineno)d %(message)s' , # it includes LogRecord attributes and it has no. of attributes (https://docs.python.org/3/library/logging.html#logrecord-attributes)
    datefmt= '%d-%b-%y %H:%M:%S',
    level= logging.DEBUG # check the order of logs in Introduction to logging
)

logging.debug("Level 1 - This is first level")
logging.info("Level 2 - This is the second level")

