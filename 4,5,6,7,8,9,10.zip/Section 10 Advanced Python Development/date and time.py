# our prg should work with UTC timezone
from datetime import datetime, timezone, timedelta
print(datetime.now(timezone.utc)) # current date & time
today = datetime.now(timezone.utc) # today's date & time
# timedelta is the timedifference.
# Below we are adding 1 day, to the current time
tomorrow = today + timedelta(days=1)  #adding 1 day in the today's date & time
print('today is ', today)
print('tomorrow is ', tomorrow)

# we can also format the date and time
print(today.strftime('%d-%m-%Y %H:%M:%S'))

user_Date = input("Enter date in YYYY-mm-dd format: ")
print(user_Date)
user_Date = datetime.strptime(user_Date, '%Y-%m-%d') # string parse time
print((user_Date))
d = user_Date.strftime('%Y-%m-%d')
print(d)

'''
# Difference between strptime and strftime
- strptime translates to
"parse (convert) string to datetime object."

- strftime translates to
"create formatted string for given time/date/datetime object according to specified format."

'''