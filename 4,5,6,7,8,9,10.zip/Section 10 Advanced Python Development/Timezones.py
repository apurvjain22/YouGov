# UTC Coordinated Universal Time
#   - used for referring a universal time, if not provided one.
#   - can always be referred to any timezone.
#   - no country uses this timezone, it is used for reference purpose.
# A date & time object in Python that does not know about timezones is called 'naive'.

from datetime import datetime
print((datetime.now())) # it will the current time but not tell the timezone.

from datetime import datetime,timezone
print(datetime.now(timezone.utc)) # it tells us the date and time with reference to UTC.

