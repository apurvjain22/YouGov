# Higher-order functions
#   - These are functions that accept other functions as parameters and run them inside of their own body.

def greet():
    print('Hello')


def before_and_after(func):
    # This parameter can be anything we like. Here the name func suggests that this is gonna be a
    # function but we could pass in whatever we want.
    print('Before..')
    func() # we will be using this parameter as if this is a fn
    print('After..')

# before_and_after(5) # when we will call this which is not a fn, it would throw an error: 'TypeError: 'int' object is not callable'

# So instead we have to pass in a fn.
# before_and_after(lambda: 5) # output: 5

# before_and_after(greet())
# first it will call greet fn and then it will have a None value returned
# Then, None will get passed as a parameter to before_and_after fn.
# and it will throw an error 'TypeError: 'NoneType' object is not callable'


# so we have to pass the fn name.
before_and_after(greet) # passed as a variable

print('Another Example')

movies = [
    {'name': 'The Matrix', 'director': 'Wachowski'},
    {'name': 'A Beautiful Day in the Neighborhood', 'director': 'Heller'},
    {'name': 'The Irishman', 'director': 'Scorsese'},
    {'name': 'Klaus', 'director': 'Pablos'},
    {'name': '1917', 'director': 'Mendes'},
]

def find_movie(expected, finder): # it runs to determine whether we are looking for the name or the director.
    for movie in movies:
        if finder(movie) == expected:
            return movie


find_by = input('What property are searching by ')
looking_for = input('What are you looking for ')
# For example they might enter name in find_by and then Klaus in looking_for and our code is going to go through
# these movies and find this one because the name property that they entered matches the value that they
# were looking for.
movie = find_movie(looking_for, lambda movie: movie[find_by])
print(movie)
