# log
#   - keeping a track of everything which ran in our app or any failure, etc.
#   - various levels of logging are there i.e. while developing a prog we might want debug logs for debugging .
#   - after the prog got developed, we might want only error logs.

import logging
'''
logging.basicConfig(format='%(asctime)s %(levelname)s:%(message)s', level=logging.DEBUG)
# we have to set the level till where the message will get printed.
# we have also formatted our logs.
# now we are getting a time at which the error occurred also the levelname.
logger  = logging.getLogger('test_logger')

logger.debug('Debug')
logger.info('info')
logger.warning('Warning')
logger.error('Error')
logger.critical('Critical')
'''
'''
# levels of log in ascending order 
1- DEBUG # will only get printed if we set the levels, as we have done above 
2- INFO # same as above
3- WARNING # will print the msg any how even if we do not set the levels
4- ERROR # same as above
5- CRITICAL # same as above

>>> so the level we define in the format from there till critical error will be shown.  
'''
print('Another Example')

logging.basicConfig(format='%(asctime)s %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s', level=logging.DEBUG)
# %(asctime)s - giving the time at which error occurs and 's' is changing to string format
# %(levelname)-8s - giving the levelname and also using 8 spaces for equal spacing among all levels
# %(filename)s - on which file the error occurs
# %(lineno)d - on which line the error occurs
# %(message)s - will show the message
logger_test = logging.getLogger('test_logger')
logger_test.debug('Debug')
logger_test.info('info')
logger_test.warning('Warning')
logger_test.error('Error')
logger_test.critical('Critical')

'''
# Basic Information
Debug : These are used to give Detailed information, typically of interest only when diagnosing problems.
Info : These are used to Confirm that things are working as expected
Warning : These are used an indication that something unexpected happened, or indicative of some problem in the near future
Error : This tells that due to a more serious problem, the software has not been able to perform some function
Critical : This tells serious error, indicating that the program itself may be unable to continue running
'''