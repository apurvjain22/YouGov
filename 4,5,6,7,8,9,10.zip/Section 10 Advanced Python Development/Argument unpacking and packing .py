accounts = {
    'checking': 1958.00,
    'savings': 4000.00
}

def add_balance(amount: float, name: str = 'checking') -> float:
    '''
    fn to update the balance of an account and return the new balance
    '''
    accounts[name] += amount
    return accounts[name]

transactions = [
  (-180.67, 'checking'),
  (-220.00, 'checking'),
  (220.00, 'savings'),
  (-15.70, 'checking'),
  (-23.90, 'checking'),
  (-13.00, 'checking'),
  (1579.50, 'checking'),
  (-600.50, 'checking'),
  (600.50, 'savings'),
]

for t in transactions:
    print(*t) # unpack any iterable into argument.
    # print(amount= t[0], name= t[1]) can also be writen like this named argument. So we can write it in any seq we want.


class User:
    def __init__(self, username, password):
        self.username = username
        self.password = password
    '''
    @classmethod
    def from_dict(cls, data):
        return cls(data['username'], data['password'])
    '''

users = [
    {'username': 'rolf', 'password': '123'},
    {'username': 'Apurv', 'password': 'password123'}
]

# users = map(User.from_dict(), users) instead of this now we can use list comprehension
# and now that we have Argument Unpacking, we don't need class method any more
# users = [User(data['username'], data['password']) for data in User]
# users = [User(username= data['username'], password= data['password']) for data in User] # named arg, not looking good
Users = [User(**data) for data in users] # dict unpacking. It unpacks the dict as a named arg to a fn.
# get the keys from the dict and pass it as a named arg to the fn.
# It's important because dictionary may not be in order.
# So we can put the password in front while calling th fn, if we want and it will still go to the right place
# because Python now match them to the name.

# If the users are in the tuple form
diff_user = [
    ('Rolf', '123'),
    ('Apurv', 'pass123')
]
User = [User(*data) for data in diff_user]
# So for each tuple here, we're going to pass them as normal arguments, called positional arguments.
# So here, Rolf would be the first parameter, 123 would be the second parameter.
# We use two operators * (for tuples) and ** (for dictionaries).
# We can use * to unpack the list so that all elements of it can be passed as different parameters.

# Argument Packing
# When we don’t know how many arguments need to be passed to a python function, we can use Packing to pack all arguments in a tuple.
# This function uses packing to sum
# unknown number of arguments
def mySum(*args):
    sum = 0
    for i in range(0, len(args)):
        sum = sum + args[i]
    return sum


# Driver code
print(mySum(1, 2, 3, 4, 5))
print(mySum(10, 20))
# args argument will take values one by one that has been passed while calling the fn.