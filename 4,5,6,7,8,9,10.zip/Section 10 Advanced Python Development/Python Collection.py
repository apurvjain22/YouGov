### Counter
from collections import Counter
temperature = [13.5, 14.0, 14.0, 14.5, 14.5, 14.5, 15.0, 16.0]
temperature_counter = Counter(temperature)
print(temperature_counter[14.5]) # it tells the freq of 14.0 in a list.

### Defaultdict
coworkers = [('Rolf', 'MIT'), ('Jen', 'Oxford'), ('Rolf', 'Cambridge'), ('Charlie', 'Manchester')]

alma_maters = {}
# we want coworker in a dict
for coworker in coworkers: # coworker is a tuple
    if coworker[0] not in alma_maters: # So we will be checking if any keys are already present or not.
        alma_maters[coworker[0]] = [] # then only we will create a new list for every key
    alma_maters[coworker[0]].append(coworker[1])

print(alma_maters['Rolf']) # every time we are iterating over a tuple, we are providing the value of that key as zero.

# we can also do it dict unpacking
print('Dict unpacking')

for coworker, place in coworkers:
    if coworker not in alma_maters:
        alma_maters[coworker] = []
    alma_maters[coworker].append(place)

print(alma_maters['Rolf'])
# print(alma_maters['Anne']) # as 'Anne' is not present so it will throw an error but with defaultdict, this could be resolved.


# by using a defaultdict
#   - defaultdict returns a new dict like object


from collections import  defaultdict

coworkers = [('Rolf', 'MIT'), ('Jen', 'Oxford'), ('Rolf', 'Cambridge'), ('Charlie', 'Manchester')]

alma_maters = defaultdict(list) # list is a type
# we can also set the default value of default as any string
# Ex: alma_maters = defaultdict(lambda: 'Default') # it sets the default value of dict as 'default'
# we want coworker in a dict
for coworker, place in coworkers: # coworker is a tuple
    alma_maters[coworker].append(place)

alma_maters.default_factory = None # this will remove the default part i.e. creating an empty list, if the key is not there and will throw an error.
# we can always change the default factory to list, dict, tuple etc.

print('Defaultdict')
print(alma_maters)
print(alma_maters['Rolf'])
# print(alma_maters['Anne']) # it will not throw an error but instead it will provide an empty list
# if we want to throw an error, we can use defaultfactory as used above

# Another example of Defaultdict
my_company = 'techlads'
coworkers = ['Jen', 'Li', 'Charlie', 'Rhys']
other_companies_coworkers = [('Rolf', 'Apple Inc.'), ('Anna', 'Google')]

coworker_companies = defaultdict(lambda: my_company) # always return my_company
# here we provided the default value of the lambda fn., i.e. a variable, it is not taken by the fn.

for person, company in other_companies_coworkers:
    coworker_companies[person] = company

print('Another Example')
print(coworker_companies)
print(coworker_companies[1])
print(coworker_companies['Rolf'])

### OrderedDict
#   - as we know that dict does not contain the elements in the ordered seq.
#   - so we use Ordered dict to contain the elements in ordered seq.
print('Ordered Dict')

from collections import OrderedDict
o = OrderedDict()
o['Rolf'] = 6
o['Jose'] = 12
o['Jen'] = 3
o['Charlie'] = 5

print(o)
o.move_to_end('Rolf')
print(o)
o.move_to_end('Charlie', last=False) # positioning the key to first if last is false
print(o)
o.popitem() # removes items from the last
print(o)
o.popitem(last=True)
print(o)
# As from Python 3.7, dict are in ordered seq so it won't be useful

### NamedTuple
#   - factory function for creating tuple subclasses with named fields
#   - Returns a new tuple subclass named typename.
#   - The new subclass is used to create tuple-like objects that have fields accessible by attribute lookup as well as being indexable and iterable.
print('NamedTuple')
from collections import namedtuple

# account = ('savings', 1850.90)
Account = namedtuple('Accounts', ['name', 'balance']) # first para: would be the name of the tuple
# and then in a list we will define the 2 fields as name and balance.
account = Account('savings', 1850.90) # by using an Account instance we will create an instance.
print(account.name)
print(account)

# syntax- _make(iterable)
#   - Class method that makes a new instance from an existing sequence or iterable.
account_1 = Account._make(account)
print('account_1 ',account_1)

# syntax- _asdict()
#   - Return a new dict which maps field names to their corresponding values
account_2 = Account._asdict(account)
print('account_2 ', account_2)



name, balance = account

### deque or double ended queue
#   - A Queue where we can add or remove things on either side is called in Python a 'deque' or 'double ended queue'.
#     i.e. we can add or remove elements either from left or from right.
#   - efficient
#   - thread safe
print('Deque')
from collections import deque
friends = deque(('Rolf', 'Charlie', 'Jen', 'Anna'))
friends.append('Jose') # it will add Jose at the end of the queue
friends.appendleft('Anthony')

print(friends)
friends.pop()
friends.popleft()
print(friends)
a = friends.popleft()
friends.append(a)
print(friends)
