def create_account(name: str, holder: str, account_holders: list = []):
    account_holders.append(holder)

    return {
        'name': name,
        'main_account_holder': holder,
        'account_holder': account_holders
    }

a1 = create_account('savings', 'Apurv')
a2 = create_account('savings', 'Shanu')
print(a2) # Output: {'name': 'savings', 'main_account_holder': 'Shanu', 'account_holder': ['Apurv', 'Shanu']}
# the reason why we are getting 2 names in the account_holders is because of the default value being given to the list.
# If we do not pass the values while calling the fn, any no. of times we are calling fn, it will always pointing to the same list.
# Because the list gets created when the fn is defined and not when it is called.
# So every time we are calling the fn, it not but appending the account_holders to the same list.
'''
We can avoid the above using either option:
1- by not providing the default empty list and also while calling the fn, we will provide the empty list there, or
2- secondly we can rewrite the code like this:

def create_account(name: str, holder: str, account_holders: list = None):
    if not account_holders:
        account_holders = []
 
So passing the value 'None' to the list wil not append the list 
and whenever we are instantiating a new list will created. 
'''

# To avoid this problem use immutable data types as ur default values.
print('Another Example')
def create_account(name: str, holder: str, account_holders: list = None):
    if not account_holders:
        account_holders = []
    account_holders.append(holder)

    return {
        'name': name,
        'main_account_holder': holder,
        'account_holder': account_holders
    }

a1 = create_account('savings', 'Apurv')
a2 = create_account('savings', 'Shanu')
a3 = create_account(('savings'))
print(a1)
print(a2)

