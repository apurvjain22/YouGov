friends_last_seen = {
    'Rolf': 31,
    'Jen': 1,
    'Anne': 7
}

def see_friends(friends, name):
    print('checking variables ',friends is friends_last_seen) # will result True because it is checking the mem loc of both the variables
    print('checking the contents ', friends == friends_last_seen) # will check the contents of the 2 variables
    print(id(friends)) # 1
    friends[name] = 0

print(id(friends_last_seen)) # 2
print(id(friends_last_seen['Rolf'])) # will result in diff mem loc

see_friends(friends_last_seen, 'Rolf') # here we are passing the contents of friends_last_seen not the variable

print(id(friends_last_seen['Rolf'])) # will result in different mem loc because we have changed one of the dict's property
print(id(friends_last_seen)) # 3
# All 3 will result in pointing to the same memory location, as the same dict is being used everywhere.

'''
So immutability can be dangerous. 
If we are changing tone of the property in dict it will change it everywhere we use it.
'''

print('2nd Example')

age = 20

def increase_age(current_age):
    current_age = current_age + 1
    return current_age

print(id(age))
print(increase_age(age))
print(id(increase_age(age)))
print(id(age))

'''
If we do this on an immutable object(here age), it will just change within the function, 
this variable(current_age) will now point somewhere else, but the outer element(age) will not change.
'''

print('3rd Example')

primes = [2, 3, 5]
print(id(primes))
primes += [7, 11] # primes.__iadd__([7, 11]), which is actually modifying the list not creating a new one.
print(id(primes))
#on the other hand if we do this
primes = primes + [7, 11] # primes.__add__([7, 11]), this is actually creating a new list and that is why a new mem loc is being assigned.
print(id(primes))
primes = [1, 2, 3] + [7, 11] # will also result in different mem loc as it is creating a new list.
print(id(primes))



