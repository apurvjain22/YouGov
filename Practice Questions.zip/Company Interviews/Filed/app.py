from datetime import datetime
from flask import Flask, request, jsonify
from marshmallow import fields, Schema, validate, validates_schema, ValidationError

app = Flask(__name__)


def validate_creditCardNumber(data):
    if len(data) == 16:
        digits = [int(c) for c in data if c.isdigit()]
        checksum = digits.pop()
        digits.reverse()
        doubled = [2 * d for d in digits[0::2]]
        total = sum(d - 9 if d > 9 else d for d in doubled) + sum(digits[1::2])
        if (total * 9) % 10 != checksum:
            raise ValidationError("Credit Card is not valid")
    else:
        raise ValidationError("The length of credit card number is incorrect")


class Requiredfields(Schema):
    creditCardNumber = fields.Str(required=True, validate=validate_creditCardNumber)
    CardHolder = fields.Str(required=True)
    ExpirationDate = fields.Date('%d-%m-%Y', required=True)
    SecurityCode = fields.Str(validate=validate.Length(equal=3))
    Amount = fields.Float(required=True, validate=validate.Range(min=0))


mandatory_fields = Requiredfields()


@app.route('/ProcessPayment', methods=['POST'])
def process_payment():
    # errors = mandatory_fields.validate(request.get_json())
    json_data = request.get_json()
    try:
        data = Requiredfields.load(self=mandatory_fields, data=json_data)
    except ValidationError as e:
        return e.messages, 400
    format_date = datetime.strptime(request.json.get('ExpirationDate'), '%d-%m-%Y')  # Date: str type -> date type
    # if errors:
    #     return "The request is invalid", 400
    payment_gateway_service_call = PaymentGateway.payment_gateway(request.get_json())
    try:
        if payment_gateway_service_call['Status'] == 1:
            if format_date < datetime.now():
                return {'message': "Expiration date is not valid"}

            return "Payment is Processed", 200  # Ok
        else:
            return "Payment is Failed", 400
    except Exception as e:
        return "Internal Server Error", 500


class PaymentGateway:
    CHEAP = "URL"
    EXPENSIVE = "URL"
    PREMIUM = "URL"

    @classmethod
    def payment_gateway(cls, data):
        # taking all the values so that it can used while calling to any of the gateway
        try:
            if data['Amount'] < 20:
                use_external_service(cls.CHEAP, data)
            elif 21 < data['Amount'] < 500:
                PaymentGateway.check_availability(cls.EXPENSIVE)
                if 'response_of_expensive_gateway_call' == 0:
                    use_external_service(cls.CHEAP, data)
            else:
                use_external_service(cls.PREMIUM, data)
                if "response_of_premium_gateway" != 1:
                    for ping in range(1, 2):
                        if 'response_to_premium_gateway' == 0:
                            use_external_service(cls.PREMIUM, data)  # calling premium gateway
                        else:
                            break
            return {'Status': 1}
        except Exception as e:
            return {'Status': 0, 'message': str(e)}

    @staticmethod
    def check_availability(url):
        """checking for a particular gateway is available or not"""
        pass


def use_external_service(url, data):
    """using this method for calling a particular payment gateway"""
    pass


if __name__ == '__main__':
    app.run(debug=True)
