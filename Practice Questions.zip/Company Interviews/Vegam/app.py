import requests


response = requests.get("https://test.mosquitto.org")
print(response.text)