@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if username is None or password is None:
            return jsonify("Missing parameters"), 400
        with open('database/users.json') as f:
            file = json.load(f)
        user = file['name']
        passw = file['password']
        if user == username and passw == password:
            token = jwt.encode(
                {'iss': user,
                 'exp': datetime.utcnow() + timedelta(minutes=30)},
                app.config['SECRET_KEY'])
            # token = {'token': token.decode('UTF-8')}
            # return jsonify({'token': token.decode('UTF-8')})
            token = token.decode('UTF-8')
            return redirect(url_for('user'), token)
        return make_response("could not verify ", 401)
    return render_template('login.html')


@app.route('/user')
@jwt_required
def user():
    return render_template('home.html')