import json
import bson

to_convert = ["items"]

for i in to_convert:

    INPUTF = i + ".bson"
    OUTPUTF = i + ".json"

    input_file = open(INPUTF, 'rb')
    output_file = open(OUTPUTF, 'w', encoding='utf-8')

    raw = (input_file.read())
    datas = bson.decode_all(raw)
    json.dump(datas, output_file)