import json

with open('../database/item_kart_db/items.bson') as f:
    conf_settings = json.load(f)

print(conf_settings)