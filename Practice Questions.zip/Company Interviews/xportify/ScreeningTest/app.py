import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import *
import json

basedir = os.path.abspath(os.path.dirname(__file__)) + '/database'

app = Flask(__name__)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'main.db')

db = SQLAlchemy(app)

with open('database/items.json') as f:
    json_data = f.read()

# print(json_data)
# data = {
#    "all_orders": json_data
# }


class SalesOrders(db.Model):
    __tablename__ = 'items'

    order_id = db.Column(db.String(50), primary_key=True, server_default='')
    order_number = db.Column(db.String(50))
    created_at = db.Column(db.String(50))


def update_orders(data):
    orders_entries = []
    for orders in json_data:
        new_entry = SalesOrders(order_id=orders['id'],
                                order_number=orders['number'])
        orders_entries.append(new_entry)
    db.session.add_all(orders_entries)
    db.session.commit()


if __name__ == "__main__":
    app.run(debug=True)