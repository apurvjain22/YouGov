from xportify.ScreeningTest.db import db

class ItemsModel(db.Model):
    print("Inside")
    __tablename__ = 'items'

    id = db.Column(db.String, primary_key=True)
    price = db.Column(db.Integer)
    name = db.Column(db.String)
    description = db.Column(db.String)
    tags = db.Column(db.String)

    def __init__(self, _id, price, name, description, tags):
        self.id = _id
        self.price = price
        self.name = name
        self.description = description
        self.tags = tags

    # def save_to_db(self):
    #     db.session.add(self)
    #     db.session.commit()
