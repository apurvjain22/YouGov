##############################################################
##############################################################
################## Item Kart #################################  
##############################################################
##############################################################

# Create an application for Item Kart
# The application should have the following functionality:
# 1. User login (Authentication)
# 2. List all the items available in the shop as per category (With limits and offsets)
# 3. Add the items to the cart (Authentication required)
# 4. List the items present in the cart (Authentication required)
# 5. Remove and Edit items of the cart (Authentication required)


# You can start writing your code for the above mentioned functionalities from here
import json
from flask import Flask, request, jsonify
from flask_jwt import JWT, jwt_required
from security import authenticate, identity
# from db import db
# from utility import DBConnectivity

app = Flask(__name__)

app.secret_key = 'Secret!'
app.config['JWT_AUTH_URL_RULE'] = '/login'
# db = DBConnectivity.create_mongo_connection()
# print(db.find_one())
jwt = JWT(app, authenticate, identity)


# @app.before_first_request
# def create_table():
#     db.create_all()


@app.route('/')
def home():
    return "home"

@app.route('/items')
@jwt_required()
def list_all_items():
    return "The user is authenticated!", 200


@app.route('/additems')  # add authentication
def add_items_to_cart():
    return "ok"


@app.route('/items-in-cart')  # add authentication
def items_in_cart():
    pass


@app.route('/update-cart')  # add authentication
def remove_or_update_items_in_cart():
    pass


if __name__ == '__main__':
    # db.init_app(app)
    # app.run(host='0.0.0.0', port=5001, debug=True)  # app.run(debug=True)
    app.run(debug=True)