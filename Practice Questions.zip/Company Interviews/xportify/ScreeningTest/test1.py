
from flask import Flask, jsonify
from flask_restful import Resource, Api, abort, reqparse
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///fuel.db'
db = SQLAlchemy(app)


class FuelConsumptionRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    odometer = db.Column(db.Float, nullable=False)
    fuelQuantity = db.Column(db.Float, nullable=False)


db.create_all()
# first_record =  FuelConsumptionRecord(odometer=0, fuelQuantity=0.0)
# second_record = FuelConsumptionRecord(odometer=100, fuelQuantity=12.5)
# # third_record = FuelConsumptionRecord(odometer=110, fuelQuantity=12.5)
# db.session.add(first_record)
# db.session.add(second_record)
# # db.session.add(third_record)
# db.session.commit()
# FuelConsumptionRecord.query.all()