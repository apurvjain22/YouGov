import json
from user import User

with open('database/users.json') as f:
    file = json.load(f)
print(file)
users = [ User(file['_id'], file['name'], file['password'])]

# users = {'id': file['_id'], 'username': file['name'], 'password': file['password']}
# username_mapping = {file['name']: {'id': file['_id'], 'username': file['name'], 'password': file['password']}}
# userid_mapping = {file['_id']: {'id': file['_id'], 'username': file['name'], 'password': file['password']}}
username_mapping = {u.username: u for u in users}
userid_mapping = {u.id: u for u in users}

def authenticate(username, password):
    print("authenticate")
    user = username_mapping.get(username)
    if user and user.password == password:
        return user


def identity(payload):
    user_id = payload['identity']
    return userid_mapping.get(user_id)
