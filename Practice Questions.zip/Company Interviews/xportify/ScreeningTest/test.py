from flask import Flask
from flask_sqlalchemy import SQLAlchemy
# from models.items import ItemsModel
import json

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class ItemsModel(db.Model):
    print("Inside")
    __tablename__ = 'items'

    _id = db.Column(db.String, primary_key=True)
    price = db.Column(db.Integer)
    name = db.Column(db.String)
    description = db.Column(db.String)
    tags = db.Column(db.String)

    # def __init__(self, _id, price, name, description, tags):
    #     self.id = _id
    #     self.price = price
    #     self.name = name
    #     self.description = description
    #     self.tags = tags

    def save_to_db(self):
        db.session.add(self)
        db.session.commit()


@app.before_first_request
def create_table():
    db.create_all()
#
d = {'_id': '55678', 'price': 123, 'name': 'Apurv', 'description': 'Boy', 'tags': 'Male' }
def create():
    with open('database/items.json') as f:
        file = json.load(f)
        print(type(file))
#         # for data in file:
#         #     user = ItemsModel(**data)
#         #     user.save_to_db()
        user = ItemsModel(**d)
        user.save_to_db()
#
@app.route('/')
def hello():
    create()
    return "ok", 200
if __name__ == '__main__':
    # from db import db
    # db.init_app(app)
    app.run(host='0.0.0.0', port=5000, threaded=True, debug=True)  # app.run(debug=True)
# import json
# from models.items import ItemsModel
# def create():
#     with open('database/items.json') as f:
#         file = json.load(f)
#         print(type(file))
#     for data in file:
#         user = ItemsModel(**data)
#         user.save_to_db()
#
#
# create()
