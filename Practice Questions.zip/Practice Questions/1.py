"""
Q- Suppose a customer entered a number and based on every number a set of characters has been associated with it.
   Just like in the keypad with number 1-'ABC' characters are associated.
   Similarly we have to create a program by making all the combinations when user enters any number
"""

import copy
num = '34'
d = {'1':'ABC', '2':'DEF', '3':'GHI', '4':'JKL'}
l = []

# making a combination of entered data
# for i in d[num[0]]:
#     for j in d[num[1]]:
#         for k in d[num[2]]:
#             l.append((i,j,k))
# print(l)

# making a universal combination of all the numbers entered by using a different method
count = len(num)
for i in range(len(num)):
    print(d[num[i]])
    if i == 0:
        [l.append(j) for j in d[num[i]]]
    else:
        new_list = copy.deepcopy(l)
        for x in new_list:
            pop = l.pop(0)
            n = ''.join(list(pop))
            for y in d[num[i]]:
                l.append((n,y))
print(l)
# converting list of tuple to
for i in l:
    l.append(''.join(i))
    l.pop(0)
print(l)

#[(('A', 'D'), 'G'), (('A', 'D'), 'H'), (('A', 'D'), 'I'),
# (('A', 'E'), 'G'), (('A', 'E'), 'H'), (('A', 'E'), 'I'),
# (('A', 'F'), 'G'), (('A', 'F'), 'H'), (('A', 'F'), 'I'),
# (('B', 'D'), 'G'), (('B', 'D'), 'H'), (('B', 'D'), 'I'),
# (('B', 'E'), 'G'), (('B', 'E'), 'H'), (('B', 'E'), 'I'),
# (('B', 'F'), 'G'), (('B', 'F'), 'H'), (('B', 'F'), 'I'),
# (('C', 'D'), 'G'), (('C', 'D'), 'H'), (('C', 'D'), 'I'),
# (('C', 'E'), 'G'), (('C', 'E'), 'H'), (('C', 'E'), 'I'),
# (('C', 'F'), 'G'), (('C', 'F'), 'H'), (('C', 'F'), 'I')]
