''' Read input from STDIN. Print your output to STDOUT '''
    #Use input() to read input from STDIN and use print to write your output to STDOUT

def main():
    # Write code here
    virus = input()
    people = input()
    composition = []
    for i in range(int(people)):
        composition.append(input())
    print(virus)
    print(people)
    print(composition)
    # for i in range(len(people)):
    #     composition = input()
    #     print("composition ", composition)
    #     for j in composition:
    #         for k in virus:
    #             if j == k:
    #                 break
    #             else:
    #                 print("NEGATIVE")
    #                 break
    #     else:
    #         print("POSITIVE")

print(main())

