from book_app import books


# sorting the books in ascending order
def print_best_books():
    best_books = sorted(books, key=lambda x: x.ratings)[:10] # as it is giving a list so we can slice to display top 10 books.
    # it is taking the first book, calling the lambda function on it,
    # and then it gives the book rating and then it will sort the books by ratings.
    for book in best_books:
        print(book)


# sorting the books in descending order
def sort_best_books():
    best_books = sorted(books, key=lambda x: x.ratings * -1)[:10]
    for book in best_books:
        print(book)


# displaying the books w.r.t price
def print_cheapest_books():
    cheapest_books = sorted(books, key= lambda x: x.price)[:10]
    for price in cheapest_books:
        print(price)


# sort the book by 2 things
def sort_books():
    best_books = sorted(books, key=lambda x: (x.ratings * -1, x.price))[:10]
    # We can return a tuple of things and it's gonna sort by ratings first and then by ratings
    # and we can continue adding keys here.
    for book in best_books:
        print(book)


print_best_books()
print('---------------')
print_cheapest_books()
print('-------------')
sort_best_books()
print('sort_books')
print(sort_books())
