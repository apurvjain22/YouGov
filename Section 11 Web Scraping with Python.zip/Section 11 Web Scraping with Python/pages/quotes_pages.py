'''
This is going to contain some code related to getting data out of the quotes page, i.e. the main page.
'''
from bs4 import BeautifulSoup
from locators.quotes_page_locators import QuotesPageLocators
from parsers.quote import QuoteParser

class Quotepage:
    def __init__(self, page):
        self.soup = BeautifulSoup(page,'html.parser')

    @property
    def quotes(self):
        locator = QuotesPageLocators.QUOTE # loc of the div's tag
        quote_tags = self.soup.select(locator) # it will fetch all the contents of all the div tag that has class 'quote'
        return [QuoteParser(e) for e in quote_tags] # the contents of div tag is then sent to parsers dicrectory

