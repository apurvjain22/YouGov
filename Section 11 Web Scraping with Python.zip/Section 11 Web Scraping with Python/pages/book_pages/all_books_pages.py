'''
extracting container's data
'''
'''
    - If we're importing things from other projects that we have not created, those go at the top,
    - our imports go directly below them, and
    - then you can put our code.
'''
import re
import logging
from bs4 import BeautifulSoup
from locators.book_locators.book_page_locators import BookPageLocators
from parsers.book_parsers.book_parser import BookParser

logger = logging.getLogger('scrapping.all_books_page')

class AllBooksPage:
    def __init__(self, page_content):
        logger.debug('Parsing page content with BeautifulSoup HTML parser.')
        self.soup = BeautifulSoup(page_content, 'html.parser')

    @property
    def books(self):
        logger.debug(f'Finding all books in the page using `{AllBooksPage.books}`.')
        locator = BookPageLocators.BOOKS
        book_tags = self.soup.select(locator) # The select is going to select every instance of this locator that it can find
        return [BookParser(e) for e in book_tags]

    @property
    def page_count(self):
        logger.debug('Finding all number of catalogue pages available...')
        locator = BookPageLocators.PAGER
        page_tags = self.soup.select_one(locator).string
        logger.info(f'Found number of catalogue pages available: `{page_tags}`.')
        end_page_pattern = 'Page [0-9]+ of ([0-9]+)'
        extract_end_page = re.search(end_page_pattern, page_tags)
        pages = int(extract_end_page[1])
        logger.debug(f'Extracted number of pages as integer: `{pages}`.')
        return pages

# Notice we are using backticks in the logger, that's just to tell that this is a value that's come from the code.
# It's not just a string. This will appear on the logs as backtick page one of 50 backtick,
# and then we can look at it and see, okay, this is something that's actually been printed from
# the code and it's not just a string that we've printed out in the logs.
