import re
from bs4 import BeautifulSoup

ITEM_HTML = '''<html><head></head><body>
<li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
    <article class="product_pod">
            <div class="image_container">
                    <a href="catalogue/a-light-in-the-attic_1000/index.html"><img src="media/cache/2c/da/2cdad67c44b002e7ead0cc35693c0e8b.jpg" alt="A Light in the Attic" class="thumbnail"></a>
            </div>
                <p class="star-rating Three">
                    <i class="icon-star"></i>
                    <i class="icon-star"></i>
                    <i class="icon-star"></i>
                    <i class="icon-star"></i>
                    <i class="icon-star"></i>
                </p>
            <h3><a href="catalogue/a-light-in-the-attic_1000/index.html" title="A Light in the Attic">A Light in the ...</a></h3>
            <div class="product_price">        
        <p class="price_color">£51.77</p>
<p class="instock availability">
    <i class="icon-ok"></i>
        In stock
</p>
    <form>
        <button type="submit" class="btn btn-primary btn-block" data-loading-text="Adding...">Add to basket</button>
    </form>
            </div>
    </article>
</li>

</body></html>
'''
class ParsedItem:
    '''
    A class to take in an HTML page (or part of it), and find properties of an item in it.
    '''

    def __init__(self, page):
        self.soup = BeautifulSoup(page, 'html.parser')

    # finding the title name
    def name(self):
        locator = 'article h3 a' # telling at which child path our element is present. # CSS Selector
        item_link = self.soup.select_one(locator) # it will whatever is present at that location
        item_name = item_link.attrs['title'] # it will fetch the title from the element we got from the location, accessing the attributes from the item_link
        return item_name

    # finding the link
    def link(self):
        locator = 'article.product_pod h3 a'
        item_link = self.soup.select_one(locator).attrs['href']
        return item_link

    # extracting the price
    def price(self):
        locator = 'article.product_pod p.price_color'
        item_price = self.soup.select_one(locator).string # £51.77
        extract_price = re.search('[0-9\.0-9]+', item_price) # 51.77
        return float(extract_price[0])

    def rating(self):
        locator = 'article.product_pod p.star-rating' # In CSS, classes are always separated by CSS and here p tag has 2 classes
        item_rating = self.soup.select_one(locator)
        classes = item_rating.attrs['class'] # ['star-rating', 'Three']
        # It doesn't necessarily that 'Three' has to be the second class, as we are seeing above.
        # We cannot just select the second element. That would be too easy.
        # we're going to recreate this classes list but without this star-rating.
        rating = [ratings for ratings in classes if ratings != 'star-rating'] # list comprehension
        # rating = filter(lambda x : x != 'star-rating', classes) # filter fn
        # print(next(rating)) # using next as filter returns a generator
        return rating[0]

item = ParsedItem(ITEM_HTML)
print(item.name())

'''
# Benefit of doing above thing is
    - we have done Encapsulation
    - We've encapsulated all the logic, inside this class and now we can reuse the class.
'''

