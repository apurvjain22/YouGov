import requests
import logging
from pages.book_pages.all_books_pages import AllBooksPage
from parsers.book_parsers import book_parser

logging.basicConfig(format= '%(asctime)s %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s',
                    datefmt='%d-%m-%Y %H:%M:%S',
                    level=logging.DEBUG,
                    filename='logs.txt')

logger = logging.getLogger('scraping')

logger.info('Loading books list...')
# If we don't want to see DEBUG messages because we're not interested in such a low level operation of our application,
# all we have to do is turn the level up to info and then they will disappear.

page_content = requests.get('http://books.toscrape.com').content # it will first fetch the page and then its content.
page = AllBooksPage(page_content)

books = page.books

'''
we're going to make our app return or, rather, export these books so that we can import them from our menu.

for book in page.books:
    print(book)
'''
'''
    - In Python, every variable that we see here, requests, all books page, page content, page and books are 
    - automatically exported so that anybody else can import them.
    - For example, as another example of what's happening here, if we go to our all_books_page,
    - we can see that it creates a few things, it creates the class all books page,
    - the books parser, all books page locators and beautiful soup.
    - Those four things are all available sort of at the top level of the file.
    - When we go into app.py, we could import beautiful soup, it would be a weird thing to do
    - but this is something we can do.
    - As soon as we create a variable like books equal page dot books which the result of launching this scraper
    - we know and getting all that data out, this variable can now be imported by another file.
'''

for page_num in range(1, page.page_count):
    url = f'http://books.toscrape.com/catalogue/page-{page_num+1}.html'
    page_content = requests.get(url).content
    logger.debug('Creating AllBooksPage from page content.')
    #  if there is a problem between the debug message and this message
    # here you know that something has gone wrong retrieving the content of the page.
    page = AllBooksPage(page_content)
    books.extend(page.books)