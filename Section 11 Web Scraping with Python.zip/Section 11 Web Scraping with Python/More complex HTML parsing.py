import re
from bs4 import BeautifulSoup

ITEM_HTML = '''<html><head></head><body>
<li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
    <article class="product_pod">
            <div class="image_container">
                    <a href="catalogue/a-light-in-the-attic_1000/index.html"><img src="media/cache/2c/da/2cdad67c44b002e7ead0cc35693c0e8b.jpg" alt="A Light in the Attic" class="thumbnail"></a>
            </div>
                <p class="star-rating Three">
                    <i class="icon-star"></i>
                    <i class="icon-star"></i>
                    <i class="icon-star"></i>
                    <i class="icon-star"></i>
                    <i class="icon-star"></i>
                </p>
            <h3><a href="catalogue/a-light-in-the-attic_1000/index.html" title="A Light in the Attic">A Light in the ...</a></h3>
            <div class="product_price">        
        <p class="price_color">£51.77</p>
<p class="instock availability">
    <i class="icon-ok"></i>
        In stock
</p>
    <form>
        <button type="submit" class="btn btn-primary btn-block" data-loading-text="Adding...">Add to basket</button>
    </form>
            </div>
    </article>
</li>

</body></html>
'''

soup = BeautifulSoup(ITEM_HTML, 'html.parser')

# finding the title name
def find_item_name():
    locator = 'article h3 a' # telling at which child path our element is present. # CSS Selector
    item_link = soup.select_one(locator) # it will fetch whatever is present at that location
    item_name = item_link.attrs['title'] # it will fetch the title from the element we got from the location, accessing the attributes from the item_link
    print(item_name)

find_item_name()

# finding the link
def find_item_link():
    locator = 'article.product_pod h3 a'
    item_link = soup.select_one(locator).attrs['href']
    print(item_link)

find_item_link()

# extracting the price
def find_item_price():
    locator = 'article.product_pod p.price_color'
    item_price = soup.select_one(locator).string # £51.77
    extract_price = re.search('[0-9\.0-9]+', item_price) # 51.77
    print(float(extract_price[0]))

find_item_price()


def find_item_rating():
    locator = 'article.product_pod p.star-rating' # In CSS, classes are always separated by CSS and here p tag has 2 classes
    item_rating = soup.select_one(locator)
    classes = item_rating.attrs['class'] # ['star-rating', 'Three']
    # It is not necessarily that 'Three' has to be the second class, as we are seeing above.
    # We cannot just select the second element. That would be too easy.
    # we're going to recreate this classes list but without this star-rating.
    rating = [ratings for ratings in classes if ratings != 'star-rating'] # list comprehension
    # rating = filter(lambda x : x != 'star-rating', classes) # filter fn
    # print(next(rating)) # using next as filter returns a generator
    print(rating[0]) # [0] is done because there would be only 1 element present in the list.

find_item_rating()

