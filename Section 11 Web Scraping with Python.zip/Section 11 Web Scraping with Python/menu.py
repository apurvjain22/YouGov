import logging
from book_app import books

logger = logging.getLogger('scraping.menu')

USER_CHOICE = '''Enter one of the following
- 'b' to look at 5-star rating books
- 'c' to look at the cheapest books
- 'n' to just get the next available book on the catalogue
- 'q' to exit
Enter your choice: '''


def print_best_books():
    logger.debug('Finding the best books by ratings...')
    best_books = sorted(books, key=lambda x: x.ratings * -1)[:10]
    for book in best_books:
        print(book)


def print_cheapest_books():
    logger.debug('Finding the best books by price...')
    cheapest_books = sorted(books, key= lambda x: x.price)[:10]
    for price in cheapest_books:
        print(price)


# using the book generator
book_generators = (x for x in books)


def get_next_book():
    logger.debug('Getting next book from generator of all books...')
    print(next(book_generators))


'''def menu():
    user_input = input(User_choice).lower()
    while user_input != 'q':
        if user_input == 'b':
            print(print_best_books())
        elif user_input == 'c':
            print_cheapest_books()
        elif user_input == 'n':
            get_next_book()
        else:
            print('Please choose a valid command')
        user_input = input(User_choice).lower()
    print('Thanks!')'''


# Alternate way of creating a menu function by using dictionary
user_choice = {
    'b': print_best_books,
    'c': print_cheapest_books,
    'n': get_next_book
    # we are not using '()' in front of the above fns while creating a dictionary
    # because after keeping those brackets it will automatically call all the fns by default without entering the choice
    # So we are calling those fns when we have to call i.e. in 'menu' fn.
}


def menu():
    user_input = input(USER_CHOICE).lower()
    while user_input != 'q':
        if user_input in ('b', 'c', 'n'):
            user_choice[user_input]() # This is going to give us the function that is associated with the input inside the dictionary,
        else:
            print('Please choose a valid command')
        user_input = input(USER_CHOICE).lower()
    print('Thanks!')
    logger.debug('Terminating program...')


menu()
#Like if you are on a try except block.

'''In the except block you'll probably want to log

some sort of warning or error to tell you that

there was an error that happened here but you caught it.'''
# And of course in some cases you cannot deal with an error
#
# because the error happened and your programme cannot continue
#
# and in those cases you should log a critical error.
# Critical message to say the programme crashed at this point.
#
# And you should know about that.
#
# Debug and info messages not so useful in your logs,
# When you're developing debug and info can be very useful.



