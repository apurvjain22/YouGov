# scrapping - act of loading a page using a python and extracting data from it
# Request library - it requests some data from a page and download it.
import requests
from bs4 import BeautifulSoup

page = requests.get('http://www.example.com')
# we're asking the requests module, and we're calling the get function within that module.
# The get function does some http transactions in the background, some http requests.
# But essentially, it goes and asks the server that is where the website is stored, for the page.
# And then the server can decide to respond with the page content, or it can decide to respond with something else.
# Once we've got that, we receive the page content, and also a couple more small bits of information,
# like a status code, which tells us whether there was an error or not, and a few more things.
# So the requests module converts that response that comes from the server, that's in that
# sort of complex format, converts it into an object in Python that we can then access the content property of.

# print(page.content) # it will give the whole html content

soup = BeautifulSoup(page.content,'html.parser')
print(soup.find('h1').string)
print(soup.select_one('p a').attrs['href'])
