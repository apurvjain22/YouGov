import re
import requests
from bs4 import BeautifulSoup
page = requests.get('http://books.toscrape.com/catalogue/page-1.html').content
simple_soup = BeautifulSoup(page,'html.parser')
locator = 'div.page_inner section ul.pager li.current'
page_tag = simple_soup.select_one(locator).string

start_page_pattern = '[0-9]+'
extract_start_page = re.search(start_page_pattern,page_tag)

end_page_pattern = 'Page [0-9]+ of ([0-9]+)'
extract_end_page = re.search(end_page_pattern, page_tag)

for page_num in range(1, int(extract_end_page[1])):
    #link_1 = {'https://books.toscrape.com/catalogue/page-'}
    #link_2 = (i, '.html')
    link = f'https://books.toscrape.com/catalogue/page-{i+1}.html'
    page = requests.get(link)
    print(page)
    '''
    locator = 'dic.inner_page section ul.pager li.current'
    simple_soup = BeautifulSoup(page,'html.parser')
    page_tag = simple_soup.select_one(locator).string

    print(page)
'''
print(extract_end_page[1])
print(extract_start_page[0])