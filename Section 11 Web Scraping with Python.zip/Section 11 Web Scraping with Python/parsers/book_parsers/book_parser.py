'''
extracting contents/components  within the main tag/container
'''
import re
import logging
from locators.book_locators.book_locators import BookLocators

logger = logging.getLogger('scraping.book_parser')


class BookParser:
    Ratings = {
        'One': 1,
        'Two': 2,
        'Three': 3,
        'Four': 4,
        'Five': 5
    }

    def __init__(self, parent):
        logger.debug(f'New Book parser created from `{parent}`.')
        # This is actually going to print out the entire HTML.

        self.parent = parent

    def __repr__(self):
        return f'A Book {self.book_name} costing £{self.price} and having {self.ratings} star rating'

    @property
    def book_name(self):
        logger.debug('Finding book name...')
        locator = BookLocators.NAME_LOCATOR
        name = self.parent.select_one(locator).attrs['title']
        logger.debug(f'Found book name, `{name}`.')
        # if something does happen after finding the book name we know that is a problem here
        # and not elsewhere in our code.
        return name

    @property
    def link(self):
        logger.debug('Finding book link...')
        locator = BookLocators.LINK_LOCATOR
        item_url = self.parent.select_one(locator).attrs['href']
        logger.debug(f'Found book link, `{item_url}`.')
        return item_url

    @property
    def price(self):
        logger.debug('Finding book price...')
        locator = BookLocators.PRICE_LOCATOR
        item_price = self.parent.select_one(locator).string
        price = re.search('[0-9]+\.[0-9]+', item_price)
        float_price = float(price[0])
        logger.debug(f'Found book price, `{float_price}`.')
        return float_price

    @property
    def ratings(self):
        logger.debug('Finding book ratings...')
        locator = BookLocators.RATINGS_LOCATOR
        item_rating = self.parent.select_one(locator)
        classes = item_rating.attrs['class']
        rating = [ratings for ratings in classes if ratings != 'star-rating']
        rating_number = BookParser.Ratings.get(rating[0])  # 'None' if not found
        logger.debug(f'Found book ratings, `{rating_number}`.')
        return rating_number
