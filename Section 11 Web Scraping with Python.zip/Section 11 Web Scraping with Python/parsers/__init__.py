'''
the parsers are very similar to pages,

but for specific things that we want to work with.
'''