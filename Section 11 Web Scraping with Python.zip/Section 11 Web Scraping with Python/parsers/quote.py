'''
this is going to get a tag, and is going to be able to find quote data within that tag.
Components
'''
from locators.quotes_locators import QuoteLocator

class QuoteParser:
    '''
    Given one of the specific quote divs, find out the data about
    the quote (quote content, author, tags).
    '''

    def __init__(self, parent): # parent: it will have the elements of all the div tags which we got from beautifulsoup
        self.parent = parent


    def __repr__(self): # representing the data.
        return f'Quote {self.content}, by {self.author}'


    @property
    def content(self): # it will fetch only the contents of the div tag.
        locator = QuoteLocator.CONTENT # locating the content
        return self.parent.select_one(locator).string # fetching the content from the elements of div tags


    @property
    def author(self):
        locator = QuoteLocator.AUTHOR
        return self.parent.select_one(locator).string


    @property
    def tags(self):
        locator = QuoteLocator.TAGS
        return [e.string for e in self.parent.select(locator)]
