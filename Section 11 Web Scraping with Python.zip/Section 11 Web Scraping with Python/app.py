import requests
from pages.quotes_pages import Quotepage

page_content = requests.get('http://quotes.toscrape.com').content # it will first fetch the page and then its content.
page = Quotepage(page_content)

for quote in page.quotes:
    print(quote)
