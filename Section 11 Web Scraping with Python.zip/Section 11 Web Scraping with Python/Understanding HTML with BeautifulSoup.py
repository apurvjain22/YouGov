from bs4 import BeautifulSoup
SIMPLE_HTML = '''

<html>
<head></head>
<body>
<h1>This a title</h1>
<p class='subtitle'>Hello, there!</p>
<p>How are you?</p>
<ul> 
    <li>Rolf</li>
    <li>Charlie</li>
    <li>Jen</li>
    <li>Jose</li>
</ul>
</body>
</html>
'''
# we will be give this HTML code to beautifulsoup to parsing(understanding the structure of the program)
simple_soup = BeautifulSoup(SIMPLE_HTML,'html.parser')

print(simple_soup.find('h1')) # it will give the contents of h1.

h1_tag = simple_soup.find('h1')
print(h1_tag.string) # getting only the contents of h1 by using the property string
# we can also put the above code in a fn
def find_title():
    h1_tag = simple_soup.find('h1') # 'find' will give only one tag
    print(h1_tag.string)

def find_list_items():
    list_items = simple_soup.find_all('li') # 'find_all' will give all the tags if many.
    list_contents = [e.string for e in list_items]
    print(list_contents)

find_title()
find_list_items()

def find_subtitle():
    paragraph = simple_soup.find('p', {'class': 'subtitle'})
    print(paragraph.string)

find_subtitle()

def find_other_paragrah():
    paragraphs = simple_soup.find_all('p')
    # print(paragraphs) # this will result in [<p class="subtitle">Hello, there!</p>, <p>How are you?</p>]
    # And from the above we want the content of 'p' where no subtitle class is there.
    other_paragrah = [p for p in paragraphs if 'subtitle' not in p.attrs.get('class', [])]
    print(other_paragrah[0].string)

find_other_paragrah()
# we are passing an empty list because in the other paragraph in HTML there is no class and while iterating over it
# we will get an Typeerror. That way, we're going to check with the subtitle is not in an empty list, instead on none.
# we can also rewrite the code p.attrs.get('class') as p.attr['class]
# get will not throw an error if the attribute is not present instead it will return None.