import aiohttp
import asyncio # it allows the us to schedule and also to mange the co-routines, the tasks.
import time

# The first thing we need to do is create the core routine and this is like a generator
# that can suspend and resume their execution at any time by using a wait.
async def fetch_page(url):
    page_start = time.time()
    async with aiohttp.ClientSession() as session: # creating a new clientSession.
        # A ClientSession just essentially creates a bunch of connections and puts them in a pool,
        # pretty much like the thread pool, so that we can reuse them without having to create new connections each time
        # we are calling it session, because it's async, which means it's just a way of potentially suspending
        # the execution of the context manager when it starts or suspending it and when it ends and resuming it.
        async with session.get(url) as response: # we wil fetch the URL we have got from the clientsession
            print(f"Page took {time.time() - page_start}")
            return response.status

    # The only purpose of asyncio and these asynchronous functions is to potentially suspend
    # execution at any point and resume it after.

# Now we will be needing the task scheduler
loop = asyncio.get_event_loop()
# when we fetch_page, what we get is a co-routine object.


# loop.run_until_complete(fetch_page('http://google.com'))
# So this is the simplest way that we can get an event_loop and run a task and a task is just an async function
# that has been defined.

tasks = [fetch_page('https://google.com') for i in range(50)]
start = time.time()
loop.run_until_complete(asyncio.gather(*tasks))
print(f"All took {time.time() - start}")