'''
The quote locators are those locators used when we want to extract information from within a single quote.
which means that the elements present inside the div section
'''
# it will locate the below elements location in the tags
class QuoteLocator:
    AUTHOR = 'small.author'
    CONTENT = 'span.text'
    TAGS = 'div.tags a.tag'