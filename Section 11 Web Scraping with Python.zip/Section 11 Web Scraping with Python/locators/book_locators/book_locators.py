'''
location of the elements of the book_quotes_page_locators
'''


class BookLocators:
    NAME_LOCATOR = 'article.product_pod h3 a'
    LINK_LOCATOR = 'article.product_pod h3 a'
    PRICE_LOCATOR = 'div.product_price p.price_color'
    RATINGS_LOCATOR = 'article.product_pod p'

