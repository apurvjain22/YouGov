'''
location of the page locators
'''


class BookPageLocators:
    BOOKS = 'section article.product_pod'
    PAGER = 'div.page_inner section ul.pager li.current'



