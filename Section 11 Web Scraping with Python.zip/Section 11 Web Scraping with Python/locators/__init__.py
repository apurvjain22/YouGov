'''
The locators is going to contain,

you guessed it, the locators of where things

are in the html, how we can find things.
'''