'''
Quotes page locators are the locators for when we want to extract quotes from a page.
'''
# it will locate only the div tags of the main page.
class QuotesPageLocators:
    QUOTE = 'div.quote'