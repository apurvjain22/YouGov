''' How sqlite works and interact '''

import sqlite3

# initializing a connection
connection = sqlite3.connect('data.db') # giving a file name

# cursor is just a pointer of a mouse. It is responsible for executing the queries like (select, insert, store ect.)
cursor = connection.cursor()

# users table has 3 columns id, username and password column.
create_table = "CREATE TABLE users (id int, username text, password text)"

cursor.execute(create_table)

# storing some data in the DB
user = (1, 'jose', 'asdf')

insert_query = 'INSERT INTO users VALUES (?, ?, ?)'
cursor.execute(insert_query, user)

# inserting many users into db
users = [
    (2, 'rolf', 'asdf'),
    (3, 'anne', 'xyz')
]

cursor.executemany(insert_query, users) # inserting one by one into DB

# retrieving data from db
select_query = "SELECT * FROM users"
for row in cursor.execute(select_query):
    print(row)

connection.commit() # saving the file
connection.close() # connection is close so that will not receive any data







