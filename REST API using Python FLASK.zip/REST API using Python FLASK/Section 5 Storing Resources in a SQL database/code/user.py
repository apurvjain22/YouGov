import sqlite3
from flask_restful import Resource, reqparse

class User():
    def __init__(self, _id, username, password):
        self.id = _id # using this because 'id' is a keyword in python
        self.username = username
        self.password = password

    # as we are not using self anywhere in the below method,
    # so we will be making the below method as a classmethod

    @classmethod
    def find_by_username(cls, username):
        ''' searching by username'''
        connection = sqlite3.connect('data.db') # initialize the connection
        cursor = connection.cursor() # initialize the cursor

        query = "SELECT * FROM users WHERE username=?"
        result = cursor.execute(query, (username,)) # sending a tuple
        row = result.fetchone() # fetching the first row.
        if row: # checking if the row is not None
            # as we are passing the parameters in order
            # user = cls(row[0], row[1], row[2]) # created a User object
            user = cls(*row) # so we can pass here a postional argument
        else:
            user = None

        # as we are not inserting or modifying anything, so we don't need to commit.
        connection.close() # closing the connection
        return user # either returning a user object or None

    @classmethod
    def find_by_id(cls, id):
        ''' searching by userid '''
        connection = sqlite3.connect('data.db')  # initialize the connection
        cursor = connection.cursor()  # initialize the cursor

        query = "SELECT * FROM users WHERE id=?"
        result = cursor.execute(query, (id,))  # sending a tuple
        row = result.fetchone()  # fetching the first row.
        if row:  # checking if the row is not None
            user = cls(*row)  # passing a postional argument
        else:
            user = None

        # as we are not inserting or modifying anything, so we don't need to commit.
        connection.close()  # closing the connection
        return user

class UserRegister(Resource):
    # parser will parse through the JSON of the request
    parser = reqparse.RequestParser()
    parser.add_argument('username', type=str, required=True, help="This field cannot be left blank")
    parser.add_argument('password', type=str, required=True, help="This field cannot be left blank")

    def post(self):
        # parse the arguments using the parser
        data = UserRegister.parser.parse_args()

        if User.find_by_username(data['username']): # if not none which means the username is already exists.
            return {'message': 'A user with that username already exists'}, 400

        connection = sqlite3.connect('data.db')
        cursor = connection.cursor()

        query = "INSERT INTO users VALUES (NULL, ?, ?)" # as id is auto incrementing, so inserting NULL.
        cursor.execute(query, (data['username'], data['password'])) # username & password has to be in a tuple.

        connection.commit()
        connection.close()

        return {'message': 'User created successfully.'}, 201
