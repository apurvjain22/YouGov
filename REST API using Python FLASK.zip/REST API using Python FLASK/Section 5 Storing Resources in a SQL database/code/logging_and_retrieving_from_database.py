'''
we're going to sign users in.
So we're going to be able to log in using SQLite.
We're going to compare that username and password to the username and password they're sending in the request.
Then we're going to see if they match,if they do, we're going to send back a jwt token.
'''
