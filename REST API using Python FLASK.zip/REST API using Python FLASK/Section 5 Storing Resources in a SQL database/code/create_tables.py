import sqlite3

"""
creating a table called as users for storing puprose 
"""

connection = sqlite3.connect('data.db')
cursor = connection.cursor()

# create_table = "CREATE TABLE IF NOT EXISTS users (id int, username text, password text)"
# In SQLite, there is a auto increment id which will auto incrementing the no., so will be using that
# So to use auto increment in SQLite we have to use below code

create_table_users = "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username text, password text)"
# Now we are going to create a new table with an auto incrementing id.
# i.e will be specifying  only username and password becoz the 'id' would be assigned automatically.
cursor.execute(create_table_users)

create_table_items = "CREATE TABLE IF NOT EXISTS items (name text, price real)" # real is a decimal point ex:10.99
cursor.execute(create_table_items)

# cursor.execute("INSERT INTO items VALUES ('test', 10.99)") # we don't require anymore

connection.commit()
connection.close()