import sqlite3
from flask_restful import Resource, reqparse
from flask_jwt import jwt_required

class Item(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('price', type=float, required=True, help='This field cannot be left blank.')

    @jwt_required() # we are using the decorator in front of the get method.
    # we will be authenticating before using the get method.
    def get(self, name):  # Retrieve item

        item = Item.find_by_name(name)
        if item:
            return item
        # below code has been used inside find_by_name() so that we can reuse the code.

        # connection = sqlite3.connect('data.db')
        # cursor = connection.cursor()
        #
        # retrieve_query = "SELECT * FROM items WHERE name=?"
        # result = cursor.execute(retrieve_query, (name,))
        # row = result.fetchone()
        # connection.close()
        #
        # if row:
        #     return {"item": {'name': row[0], 'price': row[1]}}
        return {'message': 'Item not found'}, 404 # returning if the item is None

#Note:
    # we cannot use the get() method inside a post() method becoz to access get() we have to use JWT token,
    # which could have created a problem.
    # So instead we have created find_by_name() so that it can be accessed from both the methods.
    @classmethod
    def find_by_name(cls, name):
        connection = sqlite3.connect('data.db')
        cursor = connection.cursor()

        retrieve_query = "SELECT * FROM items WHERE name=?"
        result = cursor.execute(retrieve_query, (name,))
        row = result.fetchone()
        connection.close()

        if row:
            return {"item": {'name': row[0], 'price': row[1]}}

    def post(self, name):  # creating item

        # checking if the name is already present or not.
        if Item.find_by_name(name):
            return {'message': 'An item with the name "{}" already exists'.format(name)}, 400 # Bad Request

        # then we will loading data once we found that name is not present.
        data = Item.parser.parse_args() # accessing the JSON response.
        item = {'name': name, 'price': data['price']} # we are passing the price through JSON payload.

        try:
            Item.insert(item) # creating an item by calling insert()
        except:
            return {'message': 'An error occurred while inserting'}, 500 # 500-Internal Server Error(Not users mistake)
        return item, 201

    # creating an item
    @classmethod
    def insert (cls, item):
        connection = sqlite3.connect('data.db')
        cursor = connection.cursor()

        query = "INSERT INTO items VALUES (?, ?)"
        cursor.execute(query, (item['name'], item['price']))

        connection.commit()
        connection.close()

    def delete(self, name):
        connection = sqlite3.connect('data.db')
        cursor = connection.cursor()

        query = "DELETE FROM items WHERE name=?"
        cursor.execute(query, (name,))

        connection.commit()
        connection.close()

        return {'message': 'Item deleted'}

# Note:
    # In put(), we are updating and creating a new item.
    # creating a new item, is being done in post(), but to call post would be a task for us.
    # so we have created an insert() method, which can insert items as well call from post() as well as put()
    def put(self, name):
        data = Item.parser.parse_args()

        item = Item.find_by_name(name)
        updated_item = {'name': name, 'price': data['price']}
        if item:
            try:
                Item.insert(updated_item)
            except:
                return {'message': "An error occurred while inserting the item"}, 500
        else:
            try:
                Item.update(updated_item)
            except:
                return {'message': "An error occurred while inserting the item"}, 500

        return updated_item

    # updating an item if already present while using put() method
    @classmethod
    def update(cls, item):
        connection = sqlite3.connect('data.db')
        cursor = connection.cursor()

        query = "UPDATE items SET price=? WHERE name=?"
        cursor.execute(query, (item['price'], item['name']))

        connection.commit()
        connection.close()


class ItemList(Resource):
    def get(self):
        connection = sqlite3.connect('data.db')
        cursor = connection.cursor()

        query = "SELECT * FROM items"
        result = cursor.execute(query)
        items = []
        for row in result:
            items.append({'name': row[0], 'price': row[1]})

        connection.close()

        return {'items':items}