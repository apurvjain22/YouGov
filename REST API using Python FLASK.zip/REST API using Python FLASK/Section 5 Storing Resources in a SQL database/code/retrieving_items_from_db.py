from flask import Flask
from flask_restful import Api
from flask_jwt import JWT

from security import authenticate, identity
from user import UserRegister
from item import Item, ItemList
'''
In this section 4, we will see flask restful and authentication part
and for the storage, we will be using list as a local storage.
'''


app = Flask(__name__)
app.secret_key = 'apurv' # this key should be secured and also kept in private, so that it is not visible to all.
api = Api(app)

jwt = JWT(app, authenticate, identity) # JWT creates an endpoint /auth

# items = []  # we will no longer be using in memory db

api.add_resource(Item, '/item/<string:name>')
api.add_resource(ItemList, '/items')
api.add_resource(UserRegister, '/register')

app.run(debug=True)
