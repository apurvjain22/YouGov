from flask import Flask, request
from flask_restful import Resource, Api
from flask_jwt import JWT, jwt_required

from security import authenticate, identity
'''
In this section 4, we will see flask restful and authentication part
and for the storage, we will be using list as a local storage.
'''



app = Flask(__name__)
app.secret_key = 'apurv' # this key should be secured and also kept in private, so that it is not visible to all.
api = Api(app)

jwt = JWT(app, authenticate, identity) # JWT creates an endpoint /auth
# when we call the endpoint, we will send it a username and the password and sends it to over the authenticate fn.
# We are then going to find the correct user object using that username and we're going to compare its password
# to the one that we receive through the auth endpoint.
# If they match we're going to return the user that becomes sort of the identity.
# So what happens next is the auth endpoint returns a JWT token, a JW token.
# Now that JW token in itself doesn't do anything, but we can send it to the next request we make.
# So when we send a JW token what JWT does is it calls the identity function
# and then it uses the JWT token to get the user ID and with that it gets the correct user
# for that user ID that the JWT token represents.

items = []  # contains dict for each item

class Item(Resource):

    @jwt_required() # we are using the decorator in front of the get method.
    # we will be authenticating before using the get method.
    def get(self, name):  # Retrieve item
        '''for item in items:
            if item['name'] == name:
                return item'''
        item = next(filter(lambda x: x['name'] == name, items), None) # if there is no item in the 'items' list, then
        # next would throw an error, so eradicate that, we use None.
        return {'item': item}, 200 if item else 404 # 404: Not Found


    def post(self, name):  # creating item
        if next(filter(lambda x: x['name'] == name, items), None):
            return {'message': 'An item with the name "{}" already exists'.format(name)}, 400 # Bad Request

        response = request.get_json() # accessing the JSON response.
        item = {'name': name, 'price': response['price']} # we are passing the price through JSON payload.
        items.append(item)
        return item, 201

class ItemList(Resource):
    def get(self):
        return {'items':items}

api.add_resource(Item, '/item/<string:name>')
api.add_resource(ItemList, '/items')

app.run(debug=True)
