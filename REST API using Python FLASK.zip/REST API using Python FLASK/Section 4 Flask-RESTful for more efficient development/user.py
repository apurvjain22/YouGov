# in user.py we are going to create a user object.

class User:
    def __init__(self, _id, username, password):
        self.id = _id # using this because 'id' is a keyword in python
        self.username = username
        self.password = password