from flask import Flask
from flask_restful import Resource, Api
# Resource is actually a thing that our Api can return or create or etc..
# Suppose if Api is concerned with students than students is a resource.
# Resource is mapped to our database as well.

app = Flask(__name__)
api = Api(app)

class Student(Resource):
    def get(self, name):
        return {'student':name}


api.add_resource(Student,'/student/<string:name>') # https://127.0.0.1:5000/student/Rolf

app.run()



