from flask import Flask, request
from flask_restful import Resource, Api
from flask_jwt import JWT, jwt_required

from security import authenticate, identity
'''
In this section 4, we will see flask restful and authentication part
and for the storage, we will be using list as a local storage.
'''



app = Flask(__name__)
app.secret_key = 'apurv' # this key should be secured and also kept in private, so that it is not visible to all.
api = Api(app)

jwt = JWT(app, authenticate, identity) # JWT creates an endpoint /auth

items = []  # contains dict for each item
class Item(Resource):

    @jwt_required() # we are using the decorator in front of the get method.
    # we will be authenticating before using the get method.
    def get(self, name):  # Retrieve item
        '''for item in items:
            if item['name'] == name:
                return item'''
        item = next(filter(lambda x: x['name'] == name, items), None) # if there is no item in the 'items' list, then
        # next would throw an error, so to eradicate that, we use None.
        return {'item': item}, 200 if item else 404 # 404: Not Found


    def post(self, name):  # creating item
        if next(filter(lambda x: x['name'] == name, items), None):
            return {'message': 'An item with the name "{}" already exists'.format(name)}, 400 # Bad Request

        response = request.get_json() # accessing the JSON response.
        item = {'name': name, 'price': response['price']} # we are passing the price through JSON payload.
        items.append(item)
        return item, 201

    def delete(self, name):
        global items # becoz below assigned items will acts as local to this fn.
        items = list(filter(lambda x: x['name'] != name, items))
        return {'message': 'Item delete'}


class ItemList(Resource):
    def get(self):
        return {'items':items}

api.add_resource(Item, '/item/<string:name>')
api.add_resource(ItemList, '/items')

app.run(debug=True)
