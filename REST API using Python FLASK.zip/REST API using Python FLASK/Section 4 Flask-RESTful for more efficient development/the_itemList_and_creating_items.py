from flask import Flask, request
from flask_restful import Resource, Api

'''
In this section 4, we will see flask restful and authentication part
and for the storage, we will be using list as a local storage.
'''

items = []  # contains dict for each item

app = Flask(__name__)
api = Api(app)


class Item(Resource):

    def get(self, name):  # Retrieve item
        for item in items:
            if item['name'] == name:
                return item
        return {'Status': 'Null'}, 404


    def post(self, name):  # creating item
        # request: when a client makes a request to an API, the reponse(payload) will get attached to the request variable.
        # which means the request will have the JSON payload attached to it.
        # If the request doen't have the proper content-type defined the below code will throw an error.
        response = request.get_json() # accessing the JSON response.
        # Parameters used when the reponse data is not in a JSON format.
        # silent=True -> it will throw None simply.
        # Force=True -> will always have process the response data to JSON - not recommended becoz it doesn't look into
        # header so it will always process the data even if the content type is JSON or not.
        item = {'name': name, 'price': response['price']} # we are passing the price through JSON payload.
        items.append(item)
        return item, 201

class ItemList(Resource):
    def get(self):
        return {'items':items}

api.add_resource(Item, '/item/<string:name>')
api.add_resource(ItemList, '/items')

app.run(debug=True)
