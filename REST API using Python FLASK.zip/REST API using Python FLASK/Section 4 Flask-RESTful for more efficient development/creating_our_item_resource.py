from flask import Flask
from flask_restful import Resource, Api

'''
In this section 4, we will see flask restful and authentication part
and for the storage, we will be using list as a local storage.
'''

items = []  # contains dict for each item
app = Flask(__name__)
api = Api(app)


class Item(Resource):

    def get(self, name):  # Retrieve item
        for item in items:
            if item['name'] == name:
                return item # here we don't have to use jsonify, as restful would be doing it evidently.
        return {'Status': 'Null'}, 404 # 404 is a status code, which tells object is not found.


    def post(self, name):  # creating item
        '''
        - The reason why we are accessing name through URL is because
          we will be using the same endpoint for accessing all the HTTP verbs.
        - Even though this request is going to have a JSON payload and we could send the name on that JSON file
          but we won't because we have to use all the HTTP verbs withe the same endpoint
        '''
        item = {'name': name, 'price': 12.00}
        items.append(item)
        return item, 201 # telling the client that we have processed this item in our database.
        # 201 status code, tells the object has been created

api.add_resource(Item, '/item/<string:name>')  # https://127.0.0.1:5000/item/

app.run()
