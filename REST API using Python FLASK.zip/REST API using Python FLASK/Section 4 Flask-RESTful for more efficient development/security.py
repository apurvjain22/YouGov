from user import User

# in-memory table
# users = [
#     {
#         'id':1,
#         'username': 'bob',
#         'password': 'asdf'
#     }
# ]

users = [ User(1, 'bob', 'asdf')] # new format after importing user.py

# index on 'bob'
# username_mapping = {'bob': {
#         'id':1,
#         'username': 'bob',
#         'password': 'asdf'
#     }
# }

username_mapping = {u.username: u for u in users} # assinging in a key: value pair

# userid_mapping = {1: {
#         'id':1,
#         'username': 'bob',
#         'password': 'asdf'
#     }
# }
userid_mapping = {u.id: u for u in users}

# So, why do we do this?
# So we don't have to iterate over our list every time. Essentially, we have this mapping here,
# which lets us immediately find the user that we're looking for, just by knowing its username or
# immediately find the user that we're looking for just by knowing its user ID.

# authenticate a username
def authenticate(username, password):
    user = username_mapping.get(username, None) # the benefit of using get is that we can return None, if the value is not present
    print(user)
    if user and user.password == password:
        return user

# identity function is unique to Flask JWT and the payload is the contents of the JWT.
# and then we are going to extract userid from the payload once we have the userid.
# we can retrieve the specific user that matches the payload
def identity(payload):
    userid = payload['identity']
    return username_mapping.get(userid, None)


print(authenticate('bob', 'asdf'))