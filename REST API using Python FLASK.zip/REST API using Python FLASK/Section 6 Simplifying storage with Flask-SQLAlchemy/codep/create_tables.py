import sqlite3

"""
creating a table called as users for storing puprose 
"""

connection = sqlite3.connect('data.db')
cursor = connection.cursor()

create_table_users = "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username text, password text)"
# Now we are going to create a new table with an auto incrementing id.
# i.e will be specifying  only username and password becoz the 'id' would be assigned automatically.
cursor.execute(create_table_users)


# creating a table for SQLAlchemy
create_table_items = "CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY, name text, price real)"
cursor.execute(create_table_items)

connection.commit()
connection.close()