from flask import Flask

app = Flask(__name__) #__name__ is a specia variable and it gives each file a unique name.

@app.route('/') # '/' stands for homepage of the site.
def home():
    return "Hello, world!"

@app.route('/demo')
def demo():
    return "Demo"

app.run(port=5000) # running the file.
# specifying the port means running the .py file on a particular port, and if while running interpreter throws an error,
# which means that port is used by our computer for running some other app.
# So in order to run a file, we have to change the port number.

