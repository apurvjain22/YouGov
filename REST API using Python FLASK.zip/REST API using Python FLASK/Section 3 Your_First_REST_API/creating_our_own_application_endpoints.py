from flask import Flask

app = Flask(__name__)

# server's perspective:
# POST - used to receive data
# GET - used to send data back only

# browsers perspective
# POST - used to send data
# GET - used to receive data


# storing stores containing list of dict.
stores = [
    {
        'name': 'My wonderful Store',
        'items':[
            {
                'name': 'My_item',
                'price': 15.99
            }
        ]
    }
]

# POST /store data: {name:}  - Endpoint
@app.route('/store', methods=['POST'])
def store():
    pass

# GET /store/<string: name>
@app.route('/store/<string: name>')
def get_store(name): # this name argument would be coming from the decorator
    pass

# GET /store
@app.route('/store')
def get_stores():
    pass

# POST /store/<string: name>/item {name:, price:}
@app.route('/store/<string:name>/item', methods=['POST'])
def create_item_in_store(name):
    pass

# GET /store/<string:name>/item
@app.route('/store/<string:name>/item')
def get_items_in_store(name):
    pass


app.run()