import datetime
import jwt
from flask import Flask, render_template, session, request, url_for, jsonify, redirect, make_response
from flask_sqlalchemy import SQLAlchemy
from functools import wraps


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'Secret@!'
db = SQLAlchemy(app)


class UserModel(db.Model):
    __tablename__ = 'user'

    id = db.Column(db.Integer, primary_key=True)
    firstname = db.Column(db.String)
    lastname = db.Column(db.String)
    username = db.Column(db.String, unique=True)
    password = db.Column(db.String)
    email = db.Column(db.String, unique=True)

    def __init__(self, firstname, lastname, username, password, email):
        self.firstname = firstname
        self.lastname = lastname
        self.username = username
        self.password = password
        self.email = email

    def save_to_db(self):
        db.session.add(self)
        db.session.commit()

    @classmethod
    def find_by_username(cls, username, password):
        return cls.query.filter_by(username=username, password=password).first()

# creating a database as we hit our first request
@app.before_first_request
def create_table():
    db.create_all()


@app.route('/', methods=['GET', 'POST'])
def home():
    if not session.get('logged_in'):
        return render_template('home.html')
    else:
        return render_template('home_logged_in.html') # home page having logout functionality

# checking for valid tokens
def check_for_tokens(func):
    @wraps(func)
    def wrapped(*args, **kwargs):
        token = request.args.get('token')
        if not token:
            return jsonify({'message': 'Missing token'}), 402
        try:
            data = jwt.decode(token, app.config['SECRET_KEY'])
        except:
            return jsonify({'message': 'Invalid token'}), 403
        return func(*args, **kwargs)
    return wrapped

# this endpoint is just for mediator
@app.route('/auth')
@check_for_tokens
def authorise():
    print(request.args.get('token'))
    return render_template('home_logged_in.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    elif request.method == 'POST':
        print(request.form)
        username = request.form['Username']
        password = request.form['Password']

        try:
            data = UserModel.find_by_username(username, password)
            print(data)
            if data:
                session['logged_in'] = True
                token = jwt.encode(
                    {'user': request.form['Username'],
                     'exp': datetime.datetime.utcnow() + datetime.timedelta(seconds=60) # exp is an interval b/w when
                     # the token is generated till the expiration time.
                     },
                    app.config['SECRET_KEY'])
                response = {'token': token.decode('utf-8')}
                return redirect(url_for('authorise', token=response['token']))
            else:
                # return make_response('unable to verify', 403, {'WWW-Authenticate': 'Basic realm: "login required"'})
                return make_response('unable to verify')
        except Exception as e:
            return str(e)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    else:
        firstname = request.form['FirstName']
        lastname = request.form['LastName']
        username = request.form['Username']
        password = request.form['Password']
        email = request.form['Email']
        user = UserModel(firstname, lastname, username, password, email)
        user.save_to_db()
        return render_template('login.html')


@app.route('/logout')
def logOut():
    session['logged_in'] = False
    return redirect(url_for('home'))


if __name__ == '__main__':
    app.run(debug=True)
