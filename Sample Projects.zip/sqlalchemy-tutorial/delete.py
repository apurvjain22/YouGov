from actor import Actor
from base import Session
from movies import Movie, movie_actors_association
from sqlalchemy import func, join


session = Session()

# duplicates = session.query(Movie,func.count(Movie.title).label('movie_name')).join(movie_actors_association).join(Actor)\
    # .filter(Movie.title > 1).group_by(Movie).order_by('movie_name DESC')

# duplicates = session.query(Movie, func.count()).all()
# for i in duplicates:
#     print(i.title)
