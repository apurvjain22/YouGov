from base import Session
from movies import Movie
from actor import Actor
from stuntman import Stuntman
from contact_details import ContactDetails

session = Session()

movies = session.query(Movie).all()
print('All movies')
for movie in movies:
    print("{} movie is released on {} date".format(movie.title, movie.release_date))
    print('')