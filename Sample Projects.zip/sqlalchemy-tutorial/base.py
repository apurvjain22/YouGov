from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# connecting to database with sqlite3 db using absolute path of the sqlalchemy
engine = create_engine('sqlite+pysqlite:///C:\\Users\\apurv.jain\\Downloads\\Apurv\\Trainings\\sqlalchemy-tutorial\\data1.db', echo=True)

# creating a session and also binding this session for this database
Session = sessionmaker(bind=engine)

# Declaring this file is a base of every file.
Base = declarative_base()

# creating a database
# Base.metadata.create_all(engine)