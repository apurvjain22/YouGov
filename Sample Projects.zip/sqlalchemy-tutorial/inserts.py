from datetime import date

from base import engine, Session, Base
from movies import movie_actors_association, Movie
from actor import Actor
from stuntman import Stuntman
from contact_details import ContactDetails

# generating tables in a db
Base.metadata.create_all(engine)

# creating a session
session = Session()

# create movies
yjhd = Movie("yeh jawaani hai dewaani", date(2013, 5, 13))
padmavat = Movie("padmavat", date(2018, 1, 25))
tamasha = Movie("tamasha", date(2015, 11, 26))

# creating actors
Ranbir = Actor("ranbir kapoor", date(1982, 9, 28))
Deepika = Actor("deepika padukone", date(1986, 1, 5))
Ranveer = Actor("ranveer singh", date(1985, 9, 6))
Shahid = Actor("shahid kapoor", date(1981, 2, 25))

# add actors to movies
yjhd.actors = [Ranbir, Deepika]
tamasha.actors = [Ranbir, Deepika]
padmavat.actors = [Ranveer, Deepika, Shahid]

# creating stuntmen
ranbir_stuntman = Stuntman("Ramesh", True, Ranbir)
deepika_stuntman = Stuntman("Rohini", True, Deepika)
ranveer_stuntman = Stuntman("Ramesh", True, Ranveer)
shahid_stuntman = Stuntman("Mohan", True, Shahid)

# creating contact details
ranbir = ContactDetails("123456789", "Mumbai", Ranbir)
deepika = ContactDetails("2435674898", "Banaglore", Deepika)
ranveer = ContactDetails("123456789", "Delhi", Ranveer)
shahid = ContactDetails("123456789", "Mumbai", Shahid)

# persists data
session.add(yjhd)
session.add(padmavat)
session.add(tamasha)

session.add(Ranbir)
session.add(Deepika)
session.add(Ranveer)
session.add(Shahid)

session.add(ranbir_stuntman)
session.add(deepika_stuntman)
session.add(ranveer_stuntman)
session.add(shahid_stuntman)

session.add(ranbir)
session.add(deepika)
session.add(ranveer)
session.add(shahid)

# commit and close session
session.commit()
session.close()



