def add(a, b):
    return a + b


# when we create a func or object like above, this function/object is assigned to a variable
# with the same name as the function.
print(globals())
# As we can see, the namespace contains a variable called add,
# and the value for this variable is a function object with the name add.

print(add)  # by this we are actually referencing the add function object.
# when we write add(), we're first referencing the function to get hold of the function object,
# and then the parentheses tell Python we want to call the function we just referenced.
# add and add() are both expressions, but the first evaluates to a function object,
# and the second evaluates to whatever the function returns when we call it.
