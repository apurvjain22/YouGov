# Decorator

'''
    - Decorators are special functions, because they take in some other function and they give us back a new function
    - which can do something more than the function we passed in.
'''
user = {'username': 'Apurv', 'admin_level': 'admin'}


def user_permission(func):
    if user.get(
            'admin_level') == 'admin':  # if the admin level matches, it will return my_function else raise a Runtime error
        return func
    return RuntimeError


def my_function():
    return "Password for admin panel is 1234"


my_secure_function = user_permission(my_function())
# print(my_secure_function)
# So here user_permission fn is a decorator that takes in a fn and returns a different fn.
# But the way decorator is created is a little bit different than this.
# user dict would be the same as defined above.


def user_permission(func):
    def secure_func():
        if user.get('admin_level') == 'admin':  # if the admin level matches, it will return my_function else raise a Runtime error
            return func()
        else:
            return RuntimeError
    return secure_func


def my_function():
    return "Password for admin panel is 1234"


my_secure_function = user_permission(my_function)
print(my_secure_function())
'''
    - we have created my_secure_function, an instance of user_permission fn.
    - user_permission(my_function) - In this line we are passing the reference of my_function to the user_permission fn.
    - Then python will create user_permission and secure_fn and then return the reference of secure_func.
    - The reference of the secure_func is then passed to my_secure_function.
    - And in "print(my_secure_function())" line, we are calling the secure_function().
    - Now the bock of secure_func will run, it will check the admin_level is admin or not, if it returns True, then,
    - it will call the func() i.e. my_function which is the original function.
    - And my_function will return "Password for admin panel is 1234".
    - The return value of user_permission is now assigned to my_secure_function and
    - the return value of user_permission is a reference of secure_func which assigned to my_function()
    - And now my_function doesn't pointing to the original my_function(), now it is pointing to secure_fun.
    - So whenever we run my_secure_function() now, as it will be running secure_func, and
    - my_function will get replaced by secure_func().        
'''




# So now our password for admin is secured as we cannot get the password before checking the admin_level
# Only after checking the admin_level, the passowrd will get displayed else it will return RuntimeError.

# But there is a flaw in this code, we still can get the admin password by directly running the my_function fn.

