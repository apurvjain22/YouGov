user = {'username': 'Apurv', 'admin_level': 'admin'}


def user_permission(
        func):  # here func is passed without '()' because we are passing the reference of the fn which passed here
    def secure_func():
        if user.get(
                'admin_level') == 'admin':  # if the admin level matches, it will return my_function else raise a Runtime error
            return func() # here we want to call the func and return its value which has been referenced above
        else:
            return RuntimeError

    return secure_func


@user_permission
def my_function():
    return "Password for admin panel is 1234"


# After using '@user_permission', my_function is getting defined by using user_permission decorator.
# my_secure_function = user_permission(my_function()) So there is no need of creating another fn.

print(my_function())
# my_function is getting replaced by secure_func
print(
    my_function.__name__)  # here my_function is actually getting replaced by secure_func, so secure_func names will be displayed


'''
Dry running the above code
    - After using @user_permission decorator, now func parameter will get the reference of my_function.
    - First it will go to @user_permission line where it is used, so now my_function will get passed as a reference
    - to the parameter func of user_permission fn, then secure_func will get created and 
    - the return value of the user_permission is the reference of the secure_func and the reference will get passed to
    - my_function() which will now hold the reference of the secure_func.
    - Then it will run print(my_function()) line, which holds the reference of the secure_func
    - so by using my_function() is actually calling secure_func and it will check the admin_level as 'admin'
    - if return True, then it will run the original function func() i.e. my_function() and 
    - the contents of my_function will get printed out. 
'''
