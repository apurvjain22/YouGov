'''
- Previously, what we were facing was, decorator was not generic, that means it cannot be used by another functions.
- And it will be used by some functions only.

- Now we will be looking how to make the decorators generic.
'''

import functools

user = {'username': 'Apurv', 'access_level': 'admin'}


# Now we will be using a third level higher order fns, in which decorators would be used.
# The third level fns would be taking the parameter which would be used in the decorators
def third_level(access_level):
    # In the previous code, we have used a hard code value for the access_level, which says that , if the access_level
    # is equal to the har coded value('admin') then only we will print the password.
    # So what if we change the access_level from one access_level to multiple access_level to get the password,
    # so for that we are using the access_level variable.
    def user_permission(func):
        @functools.wraps(func)
        def secure_func(panel):
            if user.get('access_level') == access_level:
                return func(panel)
            else:
                return RuntimeError

        return secure_func

    return user_permission


# decorators does not user '()' because decorators do it for us i.e. my_secure_function = user_permission(my_function)
@third_level('admin')  # here we are passing a high order fn i.e. third_level fn, which takes in a parameter
# and run as a fn and then return the value or a reference of a decorator.
# my_secure_function = third_level('admin')(my_function), this is actually happening.
# user_permission = third_level('admin')
# my_secure_function = user_permission(my_function)
def my_function(panel):
    return f"Password for {panel} panel is 1234."


print(my_function('movies'))
print(my_function.__name__)


# So when we use @user_Permission('admin'), it is actually doing this
# my_secure_function = user_permission('admin')(my_function)
# Here, user_permission fn will be called by taking 'admin' in as a parameter and,
# the return value of the function would be the reference of the secure_func,
# then the secure_function will be called by taking my_function in as a argument.