# Argument Unpacking
def add(a1, a2, a3, a4):
    return a1 + a2 + a3 + a4


print(add(1, 2, 3, 4))  # this is one process

# we have a value in a tuple we could pass each of the values of the tuple as a separate argument.
print("Tuple")
vals = 1, 2, 3, 4
print(add(*vals))
# All this has done, is unpacked the iterable, into multiple arguments and passed each one
# as a separate positional argument there.

# Similarly we can do it for the dictionary
print('Dict')
# And if we wanted to pass in each value to the corresponding parameter, we will use **vals.
# Each argument has been passed as a named argument.
vals = {'a1': 1, 'a2': 2, 'a3': 3, 'a4': 4}  # the parameter name should be same
print(add(**vals))


# How to accept arbitrary number of arguments.
def add(*args):  # we get a iterable of arguments
    return sum(args)


print(
    add(1, 2, 3, 4, 5))  # This is not a tuple or anything, these are just arguments that we're passing into a function.


# how to accept a named argument
def pretty_print(**kwargs):  # kwargs tells that it is accepting a dictionary argument
    for k, v in kwargs.items():
        print(f"for {k} we have {v}")


#pretty_print(username='Apurv',access_level='admin')  # These were condensed into a dictionary and passed in as key word arguments.

pretty_print(**{'username': 'Apurv', 'access_level': 'admin'})
# If we run this, though, it doesn't know that these are key word arguments, but we know how to turn a dictionary
# into key word arguments, which is by doing the double asterisk.

'''
    - So with single asterisk args, we can accept any number of positional arguments.
    - With double asterisk kwargs, we can accept any number of named arguments.
'''