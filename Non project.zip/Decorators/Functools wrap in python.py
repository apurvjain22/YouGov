import functools
user = {'username': 'Apurv', 'admin_level': 'admin'}


def user_permission(func):
    @functools.wraps(func) # we can now decorate multiple functions and they're each gonna keep their name.
    def secure_func(): # secure fn is actually wrapping the actual fn i.e. my_function
        # so if we tell it that secure_fn here wraps around my_function, python will understand that
        # we are extending the functionality of my_function function,
        # but we still want to keep the name and the docstring.
        if user.get('admin_level') == 'admin':
            return func()
        else:
            return RuntimeError

    return secure_func


@user_permission
def my_function():
    return "Password for admin panel is 1234"


print(my_function())
# my_function is getting replaced by secure_func
print(my_function.__name__) # once we used functools, we will be getting the original function name from which
# we get the output.

