import functools
user = {'username': 'Apurv', 'admin_level': 'admin'}


def user_permission(func):
    @functools.wraps(func)
    def secure_func(panel): # as my_function will get replaced by secure_func, and the secure_func inherits everything
        # from original function i.e. my_function. So when we call the function 'my_function('movies')',
        # it is actually running secure_func so secure_function should accept the argument.
        if user.get('admin_level') == 'admin':
            return func(panel) # while calling the original function, we must also pass in the argument that it needs
            # to call the original function.
        else:
            return RuntimeError
    return secure_func


@user_permission
def my_function(panel): # giving parameter to the fn
    return f"Password for {panel} panel is 1234"


print(my_function('movies'))
print(my_function.__name__)

