const db = require( './db' );
const path = require( 'path' );
const assert = require('assert');

const express = require( 'express' );

const app = express();

app.use( express.static( path.join( process.cwd(), 'public' ) ) );

app.get( '/', function( req, res ) {
    res.sendFile( './index.html' );
});

app.get( '/api/shows', function( req, res ) {
    
    db.getShowsCollection(function( col ) {
        col
            .find(
                {},
                { url: 1, name: 1, genres: { $slice: 1 }, status: 1, runtime: 1, schedule: 1, "rating.average": 1, "network.name": 1, "network.country.name": 1, summary: 1, image: 1 }
            )
            .limit(2)
            .toArray(function(err, docs) {
                if( err !== null ) {
                    return res.status( 500 ).json({
                        message: 'Some error occured while fetching shows'
                    });
                }
        
                res.json( docs );
            });
    });
});

app.listen( 3000, function( err ) {
    if( err ) {
        console.log( err.message );
        return;
    }

    console.log( 'server started at http://localhost:3000/' );
});