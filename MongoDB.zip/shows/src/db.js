const MongoClient = require('mongodb').MongoClient;

// Connection URL
const url = 'mongodb://localhost:27017';

// Database Name
const dbName = 'showsDB';

// Create a new MongoClient
const client = new MongoClient(url);

// Use connect method to connect to the Server
function getShowsCollection( cb ) {
    client.connect(function (err, client) {
        if( err !== null ) {
            cb( err );
            return;
        }

        console.log("Connected correctly to server");

        const db = client.db(dbName);

        const col = db.collection('shows');

        cb( col );
    });
}

function closeConnection() {
    client.close();
}

module.exports = {
    getShowsCollection,
    closeConnection
};