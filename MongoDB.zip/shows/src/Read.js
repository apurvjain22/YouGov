const db = require( './db' );
const assert = require('assert');

db.getShowsCollection(function( col ) {
    col.find( {} ).limit(2).toArray(function(err, docs) {
        assert.equal(null, err);
        
        assert.equal(2, docs.length);

        console.log( docs[0].name );
        console.log( docs[1].name );
        
        db.closeConnection();
    });
});