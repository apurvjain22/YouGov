// Details for product detail page
product = db.products.findOne({
    slug: "wheel-barrow-9092"
});

db.categories.findOne({
    _id: product.main_cat_id
});

db.reviews.find({
    product_id: product._id
});

// A "page" of reviews - limit(), sort() and skip() are cursor functions. They are called on a cursor, and they return a cursor
db.reviews.find({
    product_id: product._id
}).limit(5).skip(0)

db.reviews.find({
    product_id: product._id
}).sort({
    helpful_votes: -1, username: 1
});

db.products.find({
    category_ids: ObjectId( "6a5b1476238d3b4dd5000048" )
});