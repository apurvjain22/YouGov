- Data is denormalized to some extent to avoid joins and speed up queries
- Application requirements
- Number of reads vs writes - if number of reads >> number of writes - it is ok to duplicate fields
- Keep the number of duplicated fields at a minimum - duplicate only what is necessary
- Cardinality relationship
- Before MongoDB 3.2 there was no joins - denormalization was the way to go - now we have $lookup operator which can do joins
- Before MongoDB 4.0 we had no transaction support
// -----------
Employee <-> Project (M : N)
{
    name: 'Rahima',
    empid: 1234,
    worksOn: [
        1, 4, 5
    ]
}

// --------

Project
{
    _id: 1
    name: 'DBS Bank',
    client: 'DBS',
    budget: 1234
}
- Product <-> Reviews (1 : N)
// Design 1
Product
{
    name: 'dcw',
    reviews: [
        { reviewerName: 'fdwefw', text: 'cwcw' },
        { reviewerName: 'fdwefw', text: 'cwcw' }
    ]
}

Pro: Faster query - This schema is fine for this situation
Con: 16MB limit on document size in MongoDB