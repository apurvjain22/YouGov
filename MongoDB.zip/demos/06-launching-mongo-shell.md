$> mongo --port 27017

> show dbs;

> use local;

> show collections;

> db.startup_log.find()

> db.startup_log.find().pretty()

> cls

## The shell is a JS REPL
> let x = 1;
> let y = ++x;

> use cgiDB; // a new DB!!!

> exit; // to exit