## Features

- Free and open-source (10gen -> MongoDB)
- Windows, Mac OSX, Linux
- Free edition (community), Enterprise edition
- Atlas (MongoDB as a service) - AWS / Azure / Google Cloud
- Supports primary and secondary indexes
- GridFS (load-balanced distributed file system)
- Capped collection ("table" with fixed set of "rows")
- TTL collection 
- Drivers in all popular languages (Java, .NET, Node.js, Python)