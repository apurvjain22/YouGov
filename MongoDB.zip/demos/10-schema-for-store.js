// Collections
// 1. Products
// 2. Categories
// 3. Users
// 4. Orders
// 5. Reviews

// Relationships
// Product <-> Categories (N: 1) | (N: M)
// Product <-> Review (1: N)
// Product <-> Orders (M: N)
// Users <-> Orders (1: N)
// Users <-> Reviews (1: N)

// Access patterns
Home / Home appliances / Mixers
Product details
Reviews 

// Design the collections
Product {
    _id: ObjectId( "4e56f27890" ),
    sku: 1020,
    slug: 'iphone-1020',
    name: 'iPhone',
    description: 'hsdcbjcjwb',
    details: {
        color: '',
        cameraSpecs: ''
    },
    totalReviews: 23,
    avgRating: 4.5,
    price: 432,
    categoryId: ObjectId( "23f56a8990" ),
    tags: [
        'latest', 'phone', 'camera'
    ]
}

https://amazon.com/products/iphone-1020