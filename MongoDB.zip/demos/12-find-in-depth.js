db.users.find({
    username: 'johndoe'
})

db.users.find({
    username: /joHnDoe/i
})

// db.reviews.find({
//     helpful_votes: {
//         $gte: 5
//     },
//     helpful_votes: {
//         $lt: 10
//     }
// })

db.reviews.find({
    helpful_votes: {
        $gte: 5,
        $lt: 10
    }
})

// product which have one of the categories as the main category id
db.products.find({
    main_cat_id: {
        $in: [
            ObjectId( "9a9fb1476238d3b4dd500001" ),
            ObjectId( "9a9fb1476238d3b4dd500001" ),
            ObjectId( "6a5b1476238d3b4dd5000048" )
        ]
    }
});

// Rahima and Geeta
db.participants.find({
    "projects.name": {
        $in: [
            "CGI Intranet", "DBS banking"
        ]
    }
})


// Geeta
db.participants.find({
    "projects.name": {
        $all: [
            "CGI Intranet", "DBS banking"
        ]
    }
})

// $nin - either none of these 2 projects, or nor projects field at all
// $exists checks that a project field exists
db.participants.find({
    projects: {
        $exists: true
    },
    "projects.name": {
        $nin: [
            "CGI Intranet", "DBS banking"
        ]
    }
})

// Boolean operators - $ne, $or, $and, $not, $eq, $exists, $type
db.participants.find({
    projects: {
        $exists: true
    },
    "projects.name": {
        $not: {
            $nin: [
                "CGI Intranet", "DBS banking"
            ]
        }
    }
});

// manufacturer is NOT Acme
db.products.find({
    "details.manufacturer": {
        $ne: "Acme"
    }
})

// select all products that have color Black AND manufacturer Acme
db.products.find({
    "details.color": "Black",
    "details.manufacturer": "Acme"
})

// select all products that have color Black OR manufacturer Acme OR weight less than 40
db.products.find({
    $or: [
        { "details.color": "Black" },
        { "details.manufacturer": "Acme" },
        { "details.weight": { $gt: 40 } }
    ]
});

// select all products that have color Green AND manufacturer Acme (complicated version)
db.products.find({
    $and: [
        { "details.color": "Green" },
        { "details.manufacturer": "Acme" }
    ]
})

// One of tags "gift" | "holiday" AND One of the tags "gardening" | "landscaping"
// db.products.find({
//     tags: {
//         $in: [ "gift" | "holiday" ]
//     },
//     tags: {
//         $in: [ "gardening" | "landscaping" ]
//     }
// })

// db.products.find({
//     tags: {
//         $in: [ "gift" | "holiday" ],
//         $in: [ "gardening" | "landscaping" ]
//     }
// })

// both checks are on tags field - hence $and is necessary here
db.products.find({
    tags: {
        $and :[
            { $in: [ "gift" | "holiday" ] },
            { $in: [ "gardening" | "landscaping" ] }
        ]
    }
})

db.participants.find({
    projects: {
        $type: "array"
    }
})

// ---------

// Operators that can be used only on array-valued fields
// tag array has "gardening" and it is the first in the array
db.products.find({
    "tags.0": "gardening"
})

// matches "home" in first adddress and "CA" in second address! - hence selected
db.users.find({
    "addresses.name": "home",
    "addresses.state": "CA"
});

db.users.find({
    addresses: {
        $elemMatch: {
            name: "home",
            state: "CA"
        }
    }
});

// check size of array while selecting - select users with exactly 2 addresses
db.users.find({
    addresses: {
        $size: 2
    }
})

// $size does not support range queries
// db.users.find({
//     addresses: {
//         $size: {
//             $gt: 2
//         }
//     }
// })
// ------------