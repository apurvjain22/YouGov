# Exercises
Import the shows collection using mongoimport.