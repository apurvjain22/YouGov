// import data 
mongoimport --db nationStats --collection states --drop --file nationStats.states.json --jsonArray
