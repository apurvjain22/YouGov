# Exercises
Import the restaurants collection using mongoimport. Then solve the exercise problems given on [this page](https://www.w3resource.com/mongodb-exercises/) 