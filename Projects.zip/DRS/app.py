import os
import tkinter as tk
from tkinter import *
from tkinter import ttk, filedialog, messagebox

# creating the instance of the main window
root = tk.Tk()
root.title('Daily Review System')  # giving the title
root.option_add("*tearOff", False)
root.resizable(width=False, height=False)  # disabling the expansion of the window

user_name = tk.StringVar()  # stores the string variable
empid = tk.IntVar()  # stores the int variable

# creating the label of the text box
name_label = ttk.Label(root, text="Name")
emp_id = ttk.Label(root, text="Employee ID")
text = ttk.Label(root, text="Status ")

# using grid formatting the app
name_label.grid(row=0, columnspan=1, sticky=W, pady=2)
emp_id.grid(row=1, column=0, sticky=W, pady=2)
text.grid(row=2, column=0, sticky=W, pady=2)

# creating the text box by using grid
name_entry = ttk.Entry(root, textvariable=user_name)
emp_id_entry = ttk.Entry(root, textvariable=empid)
text_entry = tk.Text(root)

# using grid, positioning the text variable in the app
name_entry.grid(row=0, column=1, sticky=W, pady=2)
emp_id_entry.grid(row=1, column=1, sticky=W, pady=2)
text_entry.grid(row=3, column=1, sticky=W, padx=2, pady=2)


# creating submit and save button
def submit_and_save():
    name = name_entry.get()
    contents = text_entry.get("1.0", "end-1c")
    employee_id = emp_id_entry.get()
    try:
        # checking if name and contents has been entered and employee id should be equal
        if name and contents and employee_id == '0':
            messagebox.showerror(
                title="Error",
                message="Employee ID cannot be 0"
            )
        # checking if name and contents has been entered and employee id less than 5
        elif name and contents and len(employee_id) < 5:
            messagebox.showerror(
                title="Error",
                message="Employee ID should be equal to or greater than 5 digit."
            )
        # checking if name and contents has been entered and employee id greater than or equal to 5
        elif name and contents and len(employee_id) >= 5:
            if isinstance(int(employee_id), int):

                messagebox.showinfo(title='Saving Information',
                                    message='If the folder with your name is not there, then make a folder of your name '
                                            'and then save the file in the below format: '
                                            '"Name_YYYYMMDD"'
                                    )
                file_path = filedialog.asksaveasfilename()
                filename = os.path.basename(file_path)
                with open(filename, 'w') as file:
                    file.write(f"Name: {name.title()}\n")
                    file.write(f"Employee_ID: {int(employee_id)}\n")
                    file.write(f"Status: {contents}\n")
                    return messagebox.showinfo(
                    title="File Saved",
                    message="File saved successfully."
                )
            else:
                messagebox.showerror(
                    title="Error",
                    message="Employee Id should be numbers."
                )
        else:
            messagebox.showerror(
                title="Error",
                message="You have missing fields to enter"
            )
    # if after adding the details, member didn't save there status.
    except FileNotFoundError:
        messagebox.showinfo(
            title="Not Saved",
            message="File not saved"
        )


# creating frame for
frame = tk.Frame(root)

# creating button
submit_button = tk.Button(frame, text='Submit', command=submit_and_save)
close_button = tk.Button(frame, text='Close', command=root.destroy)

frame.grid(row=5, column=1)  # setting up frame
# placing the buttons in the above frame
submit_button.grid(row=0, column=0)
close_button.grid(row=0, column=1, padx=10)

root.mainloop() # running our application