from tkinter import *
root = Tk()
btn_column = Button(root, text="I'm in column 3")
btn_column.pack(side="left")

btn_columnspan = Button(root, text="I have a columnspan of 3")
btn_columnspan.grid(ipadx=20)

root.mainloop()