import requests
from bs4 import BeautifulSoup

page = requests.get('https://ucc.ent.cginet/tibbr/')
soup = BeautifulSoup(page.content, 'html.parser')
print(soup.find('form').string)
