'''
- sending an emails from a personal account using Python
- email follows smtp protocol.
- It is used to communicate between 2 different things.
- In this case we will use smtp to communicate between our python code and the gmail servers.
'''

import smtplib
from email.message import EmailMessage

email_content = ''' Dear Sir/Madam,

I am sending an email with Python. I hope you like it.

Thanks,
Apurv Jain
'''

email = EmailMessage()
email['Subject'] = 'Test email'
email['From'] = 'ourmailaddress@gmail.com'
email['To'] = 'someonelse@gmail.com'
email.set_content(email_content)

smtp_connector = smtplib.SMTP(host='smtp.gmail.com', port=587)
smtp_connector.starttls()
smtp_connector.login('jain.11apurv@gmail.com', 'Password')

smtp_connector.send_message(email) # Now the email will be send.
smtp_connector.quit() # closes the connection