import os
import tkinter as tk
from tkinter import ttk, filedialog

text_contents = dict()


def create_file(content="", title='Untitled'):
    text_area = tk.Text(notebook)
    text_area.insert("end", content) # This will insert the text at the end or the very last character.
    text_area.pack(fill='both', expand=True)
    notebook.add(text_area, text=title)
    notebook.select(text_area)

    '''
    # hash()
        - It is a method to that encodes the data into unrecognisable value.
        - It returns hash value only for immutable objects like tuple, integer, string, floats
    '''
    text_contents[str(text_area)] = hash(content) # assigning the hash value to the contents of the dict.
    # with hash value value we will get to know that the contents has been changed or not.


def check_for_changes():
    current = get_text_widget() # we will be making changes to the current widget, so that is why we are calling the fn.
    content = current.get("1.0", "end-1c")
    name = notebook.tab("current")["text"]

    if hash(content) != text_contents[str(current)]: # if the contents are not same i.e. the condition is True
        if name[-1] != "*": # if the filename has not '*' at the end of the name.
            notebook.tab("current", text=name + "*") # add '*' at the end of the filename.
    elif name[-1] == "*": # if the 1st if condition is not true then the file is not modified.
        notebook.tab("current", text=name[:-1]) # we will remove the '*' from the filename.
    # Because '*' signifies that the file is modified and also to user that the file should be saved.


def get_text_widget():
    text_widget = root.nametowidget(notebook.select()) # "Widget": is the text editor platform on which we are writing the contents.
    return text_widget

def save_file():
    file_path = filedialog.asksaveasfilename()

    try:
        filename = os.path.basename(file_path) # it will give the filename(file.txt) from the path. user/apurv/file.txt.
        text_widget = get_text_widget()
        content = text_widget.get("1.0", "end-1c")
        with open(filename, "w") as file:
            file.write(content)

    except (AttributeError, FileNotFoundError):
        print("Save operation cancelled")
        return

    notebook.tab("current", text=filename) # rename the current tab with the filename
    text_contents[str(text_widget)] = hash(content)


def open_file():
    file_path = filedialog.askopenfilename()
    try:
        filename = os.path.basename(file_path)
        with open(file_path, 'r') as file:
            content = file.read()

    except (AttributeError, FileNotFoundError):
        print("Open operation cancelled")
        return

    create_file(content, filename)

root = tk.Tk()
root.title('Text Editor')
root.option_add("*tearOff", False)

main = ttk.Frame(root)
main.pack(fill="both", expand=True, padx=1, pady=(4,0))

menubar = tk.Menu()
root.config(menu=menubar)

file_menu = tk.Menu(menubar)
menubar.add_cascade(menu=file_menu, label='File')

file_menu.add_command(label="New", command=create_file, accelerator="Ctrl+n")
file_menu.add_command(label="Open", command=open_file, accelerator="Ctrl+O")
file_menu.add_command(label="Save", command=save_file, accelerator="Ctrl+S")

notebook = ttk.Notebook(main)
notebook.pack(fill='both', expand=True)
create_file()

root.bind("<KeyPress>", lambda event: check_for_changes())
root.bind("<Control-n>", lambda event: create_file())
root.bind("<Control-o>", lambda event: open_file())
root.bind("<Control-s>", lambda event: save_file())


root.mainloop()
