import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

text_contents = dict()


def create_file(content="", title='Untitled'):
    text_area = tk.Text(notebook)
    text_area.insert("end", content) # This will insert the text at the end or the very last character.
    text_area.pack(fill='both', expand=True)
    notebook.add(text_area, text=title)
    notebook.select(text_area)

    text_contents[str(text_area)] = hash(content) # assigning the hash value to the contents of the dict.
    # with hash value value we will get to know that the contents has been changed or not.


def check_for_changes():
    current = get_text_widget() # we will be making changes to the current widget, so that is why we are calling the fn.
    content = current.get("1.0", "end-1c")
    name = notebook.tab("current")["text"]

    if hash(content) != text_contents[str(current)]: # if the contents are not same i.e. the condition is True
        if name[-1] != "*": # if the filename has not '*' at the end of the name.
            notebook.tab("current", text=name + "*") # add '*' at the end of the filename.
    elif name[-1] == "*": # if the 1st if condition is not true then the file is not modified.
        notebook.tab("current", text=name[:-1]) # we will remove the '*' from the filename.


def get_text_widget():
    text_widget = root.nametowidget(notebook.select()) # "Widget": is the text editor platform on which we are writing the contents.
    return text_widget


def confirm_quit():
    unsaved = False # by using this variable, we get to know whether the tab is saved with modified changes or not.
    # which means all the files which are open are save.

    for tab in notebook.tabs():
        text_widget = root.nametowidget(tab) # gives the current widget
        content = text_widget.get("1.0", "end-1c")

        if hash(content) != text_contents[str(text_widget)]: # if some modifications are done the file.
            unsaved = True # means one file is unsaved
            break

    if unsaved: # if the condition is true
        confirm = messagebox.askyesno(
            message="You have unsaved changes. Are you sure you want to quit?",
            icon="question",
            title="Confirm Quit"
        ) # we will ask the user whether you want to quit the file without saving or not.

        if not confirm: # if the user press "No", then we will not terminate the app, as if condition will be True.
            # if user presses "Yes", then the if condition becomes True and we will destroy the app.
            return # will run when user presses "No"
    root.destroy() # will run user presses "Yes".


def save_file():
    file_path = filedialog.asksaveasfilename()

    try:
        filename = os.path.basename(file_path) # it will give the filename(file.txt) from the path. user/apurv/file.txt.
        text_widget = get_text_widget()
        content = text_widget.get("1.0", "end-1c")
        with open(filename, "w") as file:
            file.write(content)

    except (AttributeError, FileNotFoundError):
        print("Save operation cancelled")
        return

    notebook.tab("current", text=filename) # rename the current tab with the filename
    text_contents[str(text_widget)] = hash(content)


def open_file():
    file_path = filedialog.askopenfilename()
    try:
        filename = os.path.basename(file_path)
        with open(file_path, 'r') as file:
            content = file.read()

    except (AttributeError, FileNotFoundError):
        print("Open operation cancelled")
        return

    create_file(content, filename)

root = tk.Tk()
root.title('Text Editor')
root.option_add("*tearOff", False)

main = ttk.Frame(root)
main.pack(fill="both", expand=True, padx=1, pady=(4,0))

menubar = tk.Menu()
root.config(menu=menubar)

file_menu = tk.Menu(menubar)
menubar.add_cascade(menu=file_menu, label='File')

file_menu.add_command(label="New", command=create_file, accelerator="Ctrl+n")
file_menu.add_command(label="Open", command=open_file, accelerator="Ctrl+O")
file_menu.add_command(label="Save", command=save_file, accelerator="Ctrl+S")
file_menu.add_command(label="Exit", command=confirm_quit)

notebook = ttk.Notebook(main)
notebook.pack(fill='both', expand=True)
create_file()

root.bind("<KeyPress>", lambda event: check_for_changes())
root.bind("<Control-n>", lambda event: create_file())
root.bind("<Control-o>", lambda event: open_file())
root.bind("<Control-s>", lambda event: save_file())



root.mainloop()
