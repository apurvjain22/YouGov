import tkinter as tk
from tkinter import ttk

def greet():
    print('Hello World!')

# we will be creating a Tkinter app and for that we will be needing a container for all the components of the app
# like Buttons, texts and etc.
root = tk.Tk()
root.title('Hello') # title of the app

'''
So we will be creating a 'Submit' Button in our GUI as a user interface, which will print 'Hello World' in GUI.
'''
greet_button = ttk.Button(root, text='Greet', command=greet) # ttk - Themed Tkinter Button. It is a new type of widgets.
# we will not call the greet func as it will immediately run the func.
'''
- First parameter: where the submit button will get reside and we used root here.
- Second parameter: is the text of the button when pressed.
- Third parameter: It is a callable func and tells us that which func to run when the button is clicked.
'''

# Now we will put this inside the root as root is the parent of the button and we have not placed it there yet.
# So we need to give Tkinter some information as to where we want this to appear.
greet_button.pack(side="left", fill="x", expand=True)
# the button will placed on left which will fill and also gets expand if we inc the size of the window.

# built the quit button
quit_button = ttk.Button(root, text='Quit', command=root.destroy)
# root.destroy will will destroy the app.
quit_button.pack(side="left", fill="x", expand=True)

root.mainloop() # by running this, entire python program comes to standstill as Tkinter is in its event loop.
# Now Tkinter has taken all the controls and if any buttons would be there, then it would have worked.



