import tkinter as tk
from tkinter import ttk


def create_file():
    text_area = tk.Text(notebook)
    text_area.pack(fill='both', expand=True)
    notebook.add(text_area, text='Untitled')
    notebook.select()

root = tk.Tk()
root.title("Text Editor")
root.option_add("*tearOff",False)
'''
- And what that means is, in some operating systems, the menus we'll be adding can be torn off
from the interface and placed elsewhere in your screen.
- And we want to prevent that, so the menus that we add to our application, you won't be able to like
separate from the application window.
'''

main = ttk.Frame(root)
main.pack(fill='both', expand=True, padx=1, pady=(4,0))

menubar = tk.Menu()
root.config(menu=menubar) # we have created a menu bar

file_menu = tk.Menu(menubar)
menubar.add_cascade(menu=file_menu, label="file") # this a menu item that we want to add
# to an already existing cascade inside an item.

file_menu.add_command(label="New", command=create_file)

notebook = ttk.Notebook(main)
notebook.pack(fill='both', expand=True)
create_file() # when we run the code a new text area would already come up in the Text Editor

root.mainloop()
