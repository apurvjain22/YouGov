'''
Pack, we can think of it as putting the components in the window where they fit,
given that they adhere to certain constraints that we give it.
'''

import tkinter as tk
from tkinter import ttk

root = tk.Tk()
# we are not using ttk because at this point we don't require themed or styling of those labels.
# so if we run the code now, it won't run because we have not packed our labels into the container i.e. root
    #tk.Label(root, text='Label 1', bg="Green").pack(side="left", fill="y")
    #tk.Label(root, text='Label 2', bg="red").pack(side="top", fill="x")
# After packing the labels into root
# We can see that the Label 1 will get glued to the left side and Label 2 is glued on right side of the window.
# So as we expand our window, Label 1 have no idea about the vertical distance and
# Label 2 have no idea about the horizontal distance and both will be glued in the middle of their sides.

# We will use fill now.
# So we can see that Label 1 has taken all the left vertical space and Label 2 has taken top horizontal space.
# And Label 2 is not able to use Label 1 space because Label 1 was defined first. We can also interchange the place.

# ----------------------------------------------------------------------------------------------------------------
# if we remove fill from any one then:
    #tk.Label(root, text='Label 1', bg="Green").pack(side="left")
    #tk.Label(root, text='Label 2', bg="red").pack(side="top", fill="x")
# Label 1 would be coming in the middle with the background and also Label 2 would still won't be able to take the
# place of Label 1 as the place would be reserved for Label 1.

# ------------------------------------------------------------------------------------------------------------------
# if we use expand in between:
    #tk.Label(root, text='Label 1', bg="Green").pack(side="top", fill="both", expand=True)
    #tk.Label(root, text='Label 2', bg="red").pack(side="top", fill="both", expand=True)
# So we can see that Label 1 is taking up all the space as much as there in the container and
# Label 2 is taking the vertical distance which was left in the container

# And if we use fill ="y" in the Label 1
# Then the space would still be reserved for the Label 1 but the component will fill only the y space.

# if we use both the side="Top", then,
# Then both the label will take equal space in the container

# --------------------------------------------------------------------------------------------------------------------
# creating another label
tk.Label(root, text='Label 1', bg="Green").pack(side="left",fill="both", expand=True)
tk.Label(root, text='Label 2', bg="red").pack(side="top", fill="both", expand=True)
tk.Label(root, text='Label 3', bg="red").pack(side="top", fill="both", expand=True)
# Label 1 will take all the space as per priority and the other 2 will be taking the top space and would be coming
# one after the other.
tk.Label(root, text='Label 4', bg="Green").pack(side="left",fill="both", expand=True)
# Well, because the previous label has a top, this one also appears underneath.
# So the label itself's side is irrelevant where it is placed.
# What matters is what previous elements have as their sides.
tk.Label(root, text='Label 5', bg="Green").pack(side="left",fill="both", expand=True)
# and this one appears next beside it since there is no more vertical space to go around.
root.mainloop()