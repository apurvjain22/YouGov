import tkinter as tk
from tkinter import ttk


def create_file():
    text_area = tk.Text(notebook)
    text_area.pack(fill="both", expand=True)
    notebook.add(text_area, text='Untitled')
    notebook.select(text_area) # it will point the current text book

root = tk.Tk()

main = ttk.Frame(root)
main.pack(fill="both", expand=True, padx=1, pady=(4,0)) # padx: padding on the left, pady: padding from top to bottom.

# creating the notebook where user can write anything.
notebook = ttk.Notebook(main)
notebook.pack(fill="both", expand=True)
# as this notebook is the only component which there inside a frame, so it will take the entire window.

'''# till now we have only created a Notebook, not a  file.
# creating a file where user can input.
text_area = tk.Text(notebook) # we will create text_area and we will put it inside a notebook
# Text is different from Entry as Text takes much more space than Entry.
# Entry ar just one-liners and text are multi-liners
text_area.pack(fill="both", expand=True)
notebook.add(text_area, text='Untitled')
notebook.select(text_area)'''
# we have created the a function of the create text book in the above code.

create_file()
create_file()
# select fn will always select the last text_area got created.

root.mainloop()
