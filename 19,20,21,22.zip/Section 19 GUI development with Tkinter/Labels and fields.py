'''
We will seeing that the user is inputing some data and we will be accessing those stuffs.
'''

import tkinter as tk
from tkinter import ttk

def greet():
    print(f" Hello, {user_name.get() or 'World!'}.")
    #.get() is used to retrieve the contents or the string contents of the variable.
    # if the user doesn't input anything or it is empty then it will print "Hello, World!"

root = tk.Tk()
root.title('Greet')

user_name = tk.StringVar() # It is an object which that is used to track the contents of these entry widgets.
# it would be string.

name_label = ttk.Label(root, text='Name: ') # making a label, where user can input some stuff.
name_label.pack(side="left", padx=(0,10)) # 0- left, 10 pixel- right space.
# It means that a little space would be there whenever we add a one more button.
# below item would be set behind the label.
name_entry = ttk.Entry(root, width=15, textvariable=user_name)
# textvariable is the field where this field should go and also making us to access at anytime.
name_entry.pack(side="left")
name_entry.focus()
# Focus is what you call on a particular component in tkinter, so that it appears focused on the window.

greet_button = tk.Button(root, text="Greet", command=greet)
greet_button.pack(side="left", fill="x", expand=True)

root.mainloop()