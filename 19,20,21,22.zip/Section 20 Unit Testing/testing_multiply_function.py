from unittest import TestCase
from multiply_function import divide, multiply

class TestFunctions(TestCase): # inheriting from testcase
    def test_divide_result(self):
        dividend = 15
        divisor = 3
        expected_result = 5.0
        # self.assertEqual(divide(dividend, divisor), expected_result) # if the rsult is exact
        self.assertAlmostEqual(divide(dividend, divisor), expected_result, delta=0.0001) # if the result is not exact
        # which is what the allowed difference between these two values is.
        # That is just in case there is a small inconsistency in the division there, that this will still work.

    def test_divide_negative(self):
        dividend = 15
        divisor = -3
        expected_result = -5.0
        self.assertAlmostEqual(divide(dividend, divisor), expected_result, delta=0.0001)

    def test_divide_dividen_zero(self):
        dividend = 0
        divisor = 5
        expected_result = 0
        self.assertEqual(divide(dividend, divisor), expected_result)

    def test_divide_error_on_zero(self):
        with self.assertRaises(ValueError):
            divide(25, 0)

    def test_multiply_empty(self):
        with self.assertRaises(ValueError):
            multiply() # by not passing any value, the len will be zero and it will raise a valueError

    def test_multiply_single_value(self):
        expected = 15
        self.assertEqual(multiply(expected), expected)

    def test_multiply_zero(self):
        expected = 0
        self.assertEqual(multiply(expected), expected)

    def test_multiply_result(self):
        inputs = (3, 5)
        expected = 15
        # self.assertEqual(multiply(inputs), expected) # this test is failed becoz we have passed the tuple.
        self.assertEqual(multiply(*inputs), expected) # this will pass becoz we have used argument unpacking, which
        # will pass as a individual arguments.

    def test_multiply_result_with_zero(self):
        inputs = (3, 5, 0)
        expected = 0
        self.assertEqual(multiply(*inputs), expected)

    def test_multiply_result_negative(self):
        inputs = (3, -5, 2)
        expected = -30
        self.assertEqual(multiply(*inputs), expected)

    def test_multiply_floats(self):
        inputs = (3.0, 2)
        expected = 6.0
        self.assertEqual(multiply(*inputs), expected)