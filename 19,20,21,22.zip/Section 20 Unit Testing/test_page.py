from unittest import TestCase
from unittest.mock import patch
from page import PageRequests

class TestPageRequester(TestCase):
    def setUp(self):
        self.page = TestPageRequester('https://google.com')

    # we want to make sure that when we call self.page.get, it calls the requests module.
    # We do not want to have a test that actually gets google.com.
    def test_make_request(self):
        with patch("requests.get") as mocked_get:
            self.page.get()
            mocked_get.assert_called()
            # what this does is it goes into the requests module, looks at or rather it goes into the requests import,
            # which is what we've imported here, and if we use requests.get anywhere in our application,
            # is going to be replaced by whatever this patch function returns. So, it's gonna get replaced by a mock.
