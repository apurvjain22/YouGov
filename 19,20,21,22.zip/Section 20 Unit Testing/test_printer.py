from unittest import TestCase
from Printer import Printer, PrinterError


class TestPrinter(TestCase):
    def setUp(self):
        self.printer = Printer(pages_per_s=2.0, capacity=300)

    def test_printer_within_capacity(self):
        self.printer.print(25)

    # there is a teardown class which if we want to run after after every test we can run it.

    def test_print_outside_capacity(self):  # so for every function we will be getting a new capacity
        with self.assertRaises(PrinterError):
            self.printer.print(301)  # so to breach the max capacity, we have to use 301 becoz 300 is the max limit

    def test_print_the_exact_capacity(self):
        self.printer.print(self.printer._capacity)

    def test_printer_speed(self):
        pages = 10
        expected = "Printed 10 pages in 5.00 seconds."

        result = self.printer.print(pages)
        self.assertEqual(result, expected)

    def test_speed_always_two_decimal(self):
        fast_printer = Printer(pages_per_s=3.0, capacity=300)
        pages = 11
        expected = "Printed 11 pages in 3.67 seconds."

        result = fast_printer.print(pages)
        self.assertEqual(result, expected)

    def test_multiple_print_runs(self):
        self.printer.print(25)
        self.printer.print(20)
        self.printer.print(225)

    def test_multiple_runs_end_up_error(self):
        self.printer.print(25)
        self.printer.print(20)
        self.printer.print(225)

        with self.assertRaises(PrinterError):
            self.printer.print(1)
