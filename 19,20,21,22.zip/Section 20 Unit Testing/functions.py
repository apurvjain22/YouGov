from typing import Union


def divide(dividend: object, divisor: object) -> object:
    return dividend / divisor
