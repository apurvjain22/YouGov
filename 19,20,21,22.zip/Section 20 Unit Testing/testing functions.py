from unittest import TestCase
from functions_for_testing_errors import divide

class TestFunctions(TestCase): # inheriting from testcase
    def test_divide_result(self):
        dividend = 15
        divisor = 3
        expected_result = 5.0
        # self.assertEqual(divide(dividend, divisor), expected_result) # if the rsult is exact
        self.assertAlmostEqual(divide(dividend, divisor), expected_result, delta=0.0001) # if the result is not exact
        # which is what the allowed difference between these two values is.
        # That is just in case there is a small inconsistency in the division there, that this will still work.

    def test_divide_negative(self):
        dividend = 15
        divisor = -3
        expected_result = -5.0
        self.assertAlmostEqual(divide(dividend, divisor), expected_result, delta=0.0001)

    def test_divide_dividen_zero(self):
        dividend = 0
        divisor = 5
        expected_result = 0
        self.assertEqual(divide(dividend, divisor), expected_result)

    def test_divide_error_on_zero(self):
        with self.assertRaises(ValueError):
            divide(25, 0)