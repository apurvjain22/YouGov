import requests

class PageRequests:
    def __init__(self, url:str):
        self.url = url # it will take the url

    def get(self): # calls the requests module
        return requests.get(self.url).content

