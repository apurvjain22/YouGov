from node import Node
from binary_tree import BinaryTree


head = Node(9)
'''
- So when we created head instance, it would be having 3 attributes, value, left and right.
- And after implementing head = Node(9), only 'value' variable value would be having 9 and the left and right is having None.
- So while doing "head.left = left", we are actually associating the left attribute which is the instance of the head,
- with the attribute value of the left instance.
'''
left = Node(5)
right = Node(13)

head.left = left
head.right = right

print(head)
print(head.left)
print(head.right)

# For reference we were doing Preorder Traversing.