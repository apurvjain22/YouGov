'''
- A binary tree, like a list or a set, is another data structure that we can use to hold some values.
- It has a tree like structure, where we see the elements are formed like a trees and branches.
- What we have done previously while performing the binary search on list,
- this would do exactly the same but in the forms of trees and branches.


Implemnting Binary Search on Binary Tree.
- We would be having a middle element as a parent and there would be branches to the left and right side.
- To the left smaller elements would be there as compared to the middle element
- And to the right greater element would be there.
- And it wolud follow the same procedure if go down the branches of left and right.
- They also form left and right branches to its root.
- Binary Tree has to be ordered for this to work.

'''

# Traversal of Binary Tree
'''
- Inorder Traversal : go left first, then check the node, then go right.
Purpose- useful to get an ordered list or printing the tree.

- Preorder Traversal: check node first, then go left, then go right.
Purpose- useful for saving the trees so it can be reconstructed later.
 
- Postorder Traversal: go left first, then go right, then check the node.
Purpose- useful for deleting the tree. 
'''