# check with the snippet of example which has been saved in the same folder.
from lib2to3.pytree import Node

new_node = Node(value=5, left=None, right=None)
current_node = self.head
while current_node():
    if new_node.value == current_node.value:
        raise ValueError('A node with same value already exists')
    elif new_node.value < current_node.value:
        if current_node.left:
            current_node = current_node.left
        else:
            current_node.left = new_node.value
    elif new_node.value > current_node.value:
        if current_node.right:
            current_node = current_node.right
        else:
            current_node.right = new_node.value