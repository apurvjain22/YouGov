'''
- Suppose we have a list of elements and the elements are not sorted, and we want to search an element.
- So to search an element it will take a lot of time.
- So instead we will do the searching by Binary Search.
- Where we will sort the elements in the list and then perform searching.

- Suppose we have 21 elements and there is a number which we have to find in the list.
- So we will select an element from the middle, which will led smaller numbers to the left and higher numbers to the right.
- We will discard left or right as per the element is smaller or greater than the middle element.
- The above operation will go on until we find the element in the list.
- This would be much faster and its complexity is O(log2n).


- A binary search works by, at every jump, making a decision that leaves you one of two choices.
- Go right, or go left or right.
- It means that, at every jump you're getting rid of half or approximately half of the elements remaining.
- Which is why this is a logarithmic complexity. The complexity is oh of log two n, which is much better than O-N.
'''