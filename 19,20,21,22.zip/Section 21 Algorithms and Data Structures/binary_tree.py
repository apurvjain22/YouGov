from node import Node


class BinaryTree:
    def __init__(self, head: Node):
        self.head = head

    def add(self, new_code: Node):
        current_node = self.head # current is now pointing to what head is pointing.
        while current_node:
            if new_code.value == current_node.value:
                print(current_node)
                raise ValueError('This value in the node is already present')
            elif new_code.value < current_node.value:
                if current_node.left:
                    current_node = current_node.left
                else:
                    current_node.left = new_code
                    break
            elif new_code.value > current_node.value:
                if current_node.right:
                    current_node = current_node.right
                else:
                    current_node.right = new_code
                    break
    # finding the value
    def find(self, value: int):
        current_node = self.head
        while current_node:
            if value == current_node.value:
                return current_node
            elif value > current_node.value:
                return current_node.right
            else:
                return current_node.left
        raise LookupError('A node with value {value} was not found.')

    def inorder(self):
        self._inorder_recursive(self.head)

    def _inorder_recursive(self, current_node):
        if not current_node: # if the current_node is None then only if statement will work.
            return
        self._inorder_recursive(current_node.left)
        print(current_node)
        self._inorder_recursive(current_node.right)

    def preorder(self):
        self._preorder_recursive(self.head)

    def _preorder_recursive(self, current_node):
        if not current_node:  # if the current_node is None then only if statement will work.
            return
        print(current_node)
        self._preorder_recursive(current_node.left)
        self._preorder_recursive(current_node.right)

    # finding the parent value
    def find_parent(self, value: int) -> Node:
# Case: the value, whose root node has to be found is a root node
        if self.head and self.head.value == value:
            return self.head
        current_node = self.head
        while current_node:
# Case: if the value we are looking for is found at the starting i.e. after the root/head
            if (current_node.left and current_node.left.value == value) or\
                    (current_node.right and current_node.right.value == value): # if the value passed is found,
                # it means that we got the parent node of that value.
                return current_node # passing the parent node of the passed value
# Case: if the value is greater then the root, then the current_node would point to the first node to the right of
# the root. Then again the cursor will run the above 'if' statement.
            elif value > current_node.value:
                current_node = current_node.right
# if the value is less than the root, then current_node would point to the first left node of the root.
# Then the cursor will go to run 'if' statement.
            elif value < current_node.value:
                current_node = current_node.left

    # this is for finding the right most node in the tree of the left branch ex: Node 9 -> branch 7
    def find_rightmost(self, node: Node) -> Node:
        current_node = node
        while current_node.right:
            current_node = current_node.right
            return current_node

    def delete(self, value: int):
        to_delete = self.find(value) # it would be the value
        to_delete_parent = self.find_parent(value) # it would be the parent node of the value
        if to_delete.left and to_delete.right:
            #we have 2 children
            pass
        elif to_delete.left or to_delete.right: # we have 1 child ex: Node 5
            if to_delete == to_delete_parent.left:
                to_delete_parent.left = to_delete.right or to_delete.left
            elif to_delete == to_delete_parent.right:
                to_delete_parent.right = to_delete.right or to_delete.left
            else:
                self.head = to_delete.right or to_delete.left

            pass
        else: # No children ex: Node 3
# Case: If the value and the left child of the parent node's value matches,
# then we will make the left chile of the parent node to be None
            if to_delete == to_delete_parent.left:
                to_delete_parent.left = None
# Case: If the value and the right child of the parent node's value matches,
# then we will make the right child of the parent node to be None
            elif to_delete == to_delete_parent.right:
                to_delete_parent.right = None
# Case: If there is no child of the parent node, i.e. it is a root, then we will make the connection of the root as None
            else:
                self.head = None


