from node import Node
from binary_tree import BinaryTree

tree = BinaryTree(Node(9))
tree.add(Node(5))
tree.add(Node(9))

print(tree.head)
print(tree.head.left)
print(tree.head.right)

'''
- after running "tree = BinaryTree(Node(9))", Node 9 would be having 3 attributes, value, left & right.
- And also the Node 9 will get associated with head attribute and the head would be pointing to Node 9.

Run the code in python tutor for better understanding. 
'''