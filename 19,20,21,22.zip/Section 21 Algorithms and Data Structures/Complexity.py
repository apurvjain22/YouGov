'''
Complexity
    - A complexity of O(n) just means we need a number of jumps equal to the number of elements.
    - O(n^2) means we need up to jump 9 jumps to navigate a collection of 3 elements. It will be slower than O(n).
    - O(log2n) means we need up to 3 jumps to navigate a collection of 9 elements. Much better than above 2.
    - 'n' can be think of like number of jumps to reach the nth element, starting from beginning.

'''